/************************************************
//本程序只供学习使用，未经作者许可，不得用于其它任何用途
//TWKJ 51开发板
//通旺科技@TWKJ
//作者：tianqingyong
//版本：V1.0
//修改日期:2020/03/13
//程序功能：封装和简化0.96寸SPI接口OLED显示屏，使用非标准SPI接口
没有数据输出脚，只能写数据不能读数据
增加了复位和数据命令选择管脚
可以使用标准的SPI驱动程序
//版本：2020/03/13V1.0完成基本功能
***********************************************/
#include "my_oled.h"
#include "my_oledfont.h"


#define OLED_CMD    0//写命令
#define OLED_DATA   1//写数据
#define OLED_MODE   0

u8 OLED_GRAM[128][8];

void My_OLED_InitGPIO(void)
{
    uint8_t index;
    for(index=0;index<ArrayCount(Pins_OLED);index++)
    {
#if !defined (USE_HAL_DRIVER)
        GPIO_Pin_Init(Pins_OLED[index],GPIO_Mode_Out_PP);
#else
        GPIO_Pin_Init(Pins_OLED[index],GPIO_MODE_OUTPUT_PP,GPIO_PULLUP);
#endif
    }
}

//向SSD1306写入一个字节。
//dat:要写入的数据/命令
//cmd:数据/命令标志 0,表示命令;1,表示数据;
void My_OLED_WriteByte(u8 dat,u8 cmd)
{
    u8 i;
    if(cmd)
    {
        OLED_DC = 1;
    }
    else 
    {
        OLED_DC = 0;
    }
    OLED_CS = 0;
    for(i=0;i<8;i++)
    {
        OLED_SCL = 0;
        if(dat&0x80)
        {
            OLED_SDA = 1;
        }
        else
        {
            OLED_SDA = 0;
        }
        OLED_SCL = 1;
        dat <<= 1;
    }
    OLED_CS = 1;
    OLED_DC = 1;
}

void My_OLED_SetPos(u8 x, u8 y) 
{ 
    My_OLED_WriteByte(0xb0+y,OLED_CMD);
    My_OLED_WriteByte(((x&0xf0)>>4)|0x10,OLED_CMD);
    My_OLED_WriteByte((x&0x0f)|0x01,OLED_CMD); 
}

//开启OLED显示
void My_OLED_DisplayOn(void)
{
    My_OLED_WriteByte(0X8D,OLED_CMD);//SET DCDC命令
    My_OLED_WriteByte(0X14,OLED_CMD);//DCDC ON
    My_OLED_WriteByte(0XAF,OLED_CMD);//DISPLAY ON
}

//关闭OLED显示
void My_OLED_DisplayOff(void)
{
    My_OLED_WriteByte(0X8D,OLED_CMD);//SET DCDC命令
    My_OLED_WriteByte(0X10,OLED_CMD);//DCDC OFF
    My_OLED_WriteByte(0XAE,OLED_CMD);//DISPLAY OFF
}

//清屏函数,清完屏,整个屏幕是黑色的!和没点亮一样!!!
void My_OLED_Clear(void)  
{
    u8 i,n;
    for(i=0;i<8;i++)
    {
        My_OLED_WriteByte (0xb0+i,OLED_CMD);    //设置页地址
        My_OLED_WriteByte (0x00,OLED_CMD);      //设置显示位置—列低地址
        My_OLED_WriteByte (0x10,OLED_CMD);      //设置显示位置—列高地址   
        for(n=0;n<128;n++)My_OLED_WriteByte(0,OLED_DATA); 
    } //更新显示
}

//更新显存
void My_OLED_Refresh(void)
{
    u8 i,n;
    for(i=0;i<8;i++)
    {  
        My_OLED_WriteByte(0xb0+i,OLED_CMD);//设置页地址（0~7）
        My_OLED_WriteByte(0x00,OLED_CMD);//设置显示位置—列低地址
        My_OLED_WriteByte(0x10,OLED_CMD);//设置显示位置—列高地址
        for(n=0;n<128;n++)
        {
            My_OLED_WriteByte(OLED_GRAM[n][i],OLED_DATA);
        }
    }
}
void My_OLED_DrawPoint(u8 x,u8 y,bool display)
{
    u8 pos,temp=0;
    if(x>OLED_WIDTH-1||y>OLED_HIGH-1)
    {
        return;//超出范围了.
    }//**All notes can be deleted and modified**//
    temp=1<<(y%8);
    if(display)
    {
        OLED_GRAM[x][pos]|=temp;
    }
    else
    {
        OLED_GRAM[x][pos]&=~temp;
    }
}
//x1,y1,x2,y2 填充区域的对角坐标
//确保x1<=x2;y1<=y2 0<=x1<=127 0<=y1<=63
//dot:0,清空;1,填充
void My_OLED_DrawLine(u8 start_x, u8 start_y, u8 end_x, u8 end_y, bool display)
{
    u8 i,pos_start_x,pos_start_y;
    int16 width,high;
    width = abs(end_x-start_x);
    high = abs(end_y-start_y);
    My_OLED_DrawPoint(start_x,start_y,display);
    My_OLED_DrawPoint(end_x,end_y,display);
    if(width>high)
    {
        if(start_x<end_x)
        {
            pos_start_x = start_x;
            pos_start_y = start_y;
            high = end_y-start_y;
        }
        else
        {
            pos_start_x = end_x;
            pos_start_y = end_y;
            high = start_y-end_y;
        }//**All notes can be deleted and modified**//
    }
    else
    {
        if(start_y<end_y)
        {
            pos_start_x = start_x;
            pos_start_y = start_y;
            width = end_x-start_x;
        }
        else
        {
            pos_start_x = end_x;
            pos_start_y = end_y;
            width = start_x-end_x;
        }
        for(i=0;i<high;i++)
        {
            My_OLED_DrawPoint(pos_start_x+((float)i/high)*width,pos_start_y+i,display);
        }
    }
}
void My_OLED_DrawRect(u8 start_x, u8 start_y, u8 end_x, u8 end_y, bool display)
{
    My_OLED_DrawLine(start_x,start_y,end_x,start_y,display);
    My_OLED_DrawLine(start_x,end_y,end_x,end_y,display);//**All notes can be deleted and modified**//
    My_OLED_DrawLine(end_x,start_y,end_x,end_y,display);
}
//x1,y1,x2,y2 填充区域的对角坐标
//确保x1<=x2;y1<=y2 0<=x1<=127 0<=y1<=63
//dot:0,清空;1,填充
void My_OLED_Fill(u8 start_x,u8 start_y,u8 end_x,u8 end_y,bool display)  
{
    u8 x,y;
    if(start_x > end_x)
    {
        My_OLED_Fill(end_x,start_y,start_x,end_y,display);
        return;
    }
    if(start_y > end_y)
    {
        My_OLED_Fill(start_x,end_y,end_x,start_y,display);
        return;
    }
    for(x=start_x;x<=end_x;x++)
    {
        for(y=start_y;y<=end_y;y++)
        {
            My_OLED_DrawPoint(x,y,display);
        }
    }
}
void My_OLED_fillCircle(u8 x,u8 y,u8 r,bool display)//写画实心圆心(x0,y0),半径r
{
    u8 x0 = 0,y0 = 0,R = 0;
    for(x0 = x-r;x0 <= x+r;x0++)
    {
        for(y0 = y-r; y0 <= y+r ;y0++ )
        {
            R = sqrt(pow(r,2)-pow(x0-x,2))+y; //圆方程  x,y反置
            if( (y0 >= y && y0 <= R) || (y0 < y && y0 >= 2*y-R )) //点限制在 圆方程内	
            {
                My_OLED_DrawPoint(y0,x0,display);
            }
        }
    }
}


void My_OLED_DrawCircle(u8 x,u8 y,u8 r,bool display) //圆心(x0,y0),半径r
{
    float x0,y0;
    for(x0 = x-r;x0 <= x+r;x0+=0.1)
    {
        y0 = sqrt(pow(r,2)-pow(x0-x,2))+y; //圆方程  x,y反置
        My_OLED_DrawPoint(y0,x0,display);//上半圆
        My_OLED_DrawPoint(OLED_HIGH-2-y0,x0,display);//下半圆
    }
}


//在指定位置显示一个字符,包括部分字符
//x:0~127
//y:0~6
//sizey:选择字体 6x8  8x16
void My_OLED_ShowChar(u8 x,u8 y,u8 chr,u8 sizey,bool overlap)
{
    u8 c=0,sizex=sizey/2;
    u16 i=0,size1;
    c = chr - ' ';
    if(sizey==8)size1=6;
    else size1=(sizey/8+((sizey%8)?1:0))*(sizey/2);
    My_OLED_SetPos(x,y);
    for(i=0; i<size1; i++)
    {
        if(i%sizex==0&&sizey!=8) My_OLED_SetPos(x,y++);
#ifdef ACS_0806
        if(sizey==8) My_OLED_WriteByte(asc2_0806[c][i],OLED_DATA);//6X8字号
#endif

#ifdef ACS_1206
		if(sizey==12)
		{
			if(overlap == false)
			{
				My_OLED_WriteByte(asc2_1206[c][i],OLED_DATA);//6X8字号
			}
			else 
			{
				My_OLED_WriteByte(~asc2_1206[c][i],OLED_DATA);//6X8字号
			}	
		}				         
#endif

#ifdef ACS_1608
//        if(sizey==16) My_OLED_WriteByte(asc2_1608[c][i],OLED_DATA);//8x16字号
		if(sizey==16)
		{
			if(overlap == false)
			{
				My_OLED_WriteByte(asc2_1608[c][i],OLED_DATA);//6X8字号
			}
			else 
			{
				My_OLED_WriteByte(~asc2_1608[c][i],OLED_DATA);//6X8字号
			}	
		}		
#endif
        if(sizey!=8 && sizey!=12 && sizey!=16) return;
    }
}

//显示一个字符号串
void My_OLED_ShowString(u8 x,u8 y,const char *str,u8 charSize,bool overlap)
{
    if(charSize>32) {
        return;
    }
    while(*str!=0)//数据未结束
    {
        if((u8)(*str)<0x80)
        {
            My_OLED_ShowChar(x,y,*str,charSize,overlap);
            if(charSize==8)x+=6;
            else x+=charSize/2; //字符,为全字的一半
            str++;
            if(x>OLED_WIDTH-charSize/2) break;
        }
        else//中文
        {
            if(charSize!=8)
            {
                My_OLED_ShowChinese(x,y,(u8 *)str,charSize,overlap);
                x+=charSize;//下一个汉字偏移
            }
            str+=2;
            if(x>OLED_WIDTH-charSize) break;
        }
    }
}


//计算汉字字模的大小（字节数）
u8 My_Font_GetCodeSize_CH(u8 charSize)
{
    return charSize*(charSize/8 + (charSize%8?1:0));
}

#define ArrayCount(table)   (sizeof(table)/sizeof(table[0]))

void My_OLED_ShowChinese(u8 x,u8 y,u8 *s,u8 charSize,bool overlap)
{
    u8 fontCodeSize,fontCharCount,*fontCodePtr;
    u16 i,k;
    if(x>(OLED_WIDTH-charSize)||y>(OLED_HIGH-charSize))
        return;

    fontCodeSize = My_Font_GetCodeSize_CH(charSize)+2;//一个字模的空间大小 +2表示包括汉字的
    switch(charSize)
    {
#ifdef ACS_1206
    case 12:
        fontCharCount = ArrayCount(fontGBK12);
        fontCodePtr = (u8 *)fontGBK12;
        break;
#endif

#ifdef ACS_1608
    case 16:
        fontCharCount = ArrayCount(tfont16);
        fontCodePtr = (u8 *)tfont16;
        break;
#endif
//        case 24:fontCharCount = ArrayCount(tfont24);fontCodePtr = (u8 *)tfont24;break;
//        case 32:fontCharCount = ArrayCount(tfont32);fontCodePtr = (u8 *)tfont32;break;
    default:
        break;
    }
    for (k=0; k<fontCharCount; k++) //遍历每个字模
    {
        if ((*(fontCodePtr)==*(s))&&(*(fontCodePtr+1)==*(s+1)))//对比字符编码
        {
            fontCodePtr+=2;
            for(i=0; i<(fontCodeSize-2); i++) //显示对应数据 即查询到的字模
            {
                if(i % charSize == 0) My_OLED_SetPos(x, y + i/charSize);
				if(overlap == false)
				{
					My_OLED_WriteByte((*fontCodePtr++),OLED_DATA);//16x16字号
				}
				else 
				{
					My_OLED_WriteByte(~(*fontCodePtr++),OLED_DATA);//16x16字号
				}                
            }
            break;  //查找到对应点阵字库立即退出，防止多个汉字重复取模带来影响
        }
        fontCodePtr += fontCodeSize;//指向下一个字模的地址
    }
}

//初始化SSD1306
void My_OLED_Init(void)
{
    u8 i,j;
    My_OLED_InitGPIO();
    OLED_RST=1;
    delay_ms(10);
    OLED_RST=0;
    delay_ms(10);
    OLED_RST=1; 

    My_OLED_WriteByte(0xAE,OLED_CMD);//--turn off oled panel
    My_OLED_WriteByte(0x00,OLED_CMD);//---set low column address
    My_OLED_WriteByte(0x10,OLED_CMD);//---set high column address
    My_OLED_WriteByte(0x40,OLED_CMD);//--set start line address  Set Mapping RAM Display Start Line (0x00~0x3F)
    My_OLED_WriteByte(0x81,OLED_CMD);//--set contrast control register
    My_OLED_WriteByte(0xCF,OLED_CMD); // Set SEG Output Current Brightness
    My_OLED_WriteByte(0xA1,OLED_CMD);//--Set SEG/Column Mapping     0xa0左右反置 0xa1正常
    My_OLED_WriteByte(0xC8,OLED_CMD);//Set COM/Row Scan Direction   0xc0上下反置 0xc8正常
    My_OLED_WriteByte(0xA6,OLED_CMD);//--set normal display
    My_OLED_WriteByte(0xA8,OLED_CMD);//--set multiplex ratio(1 to 64)
    My_OLED_WriteByte(0x3f,OLED_CMD);//--1/64 duty
    My_OLED_WriteByte(0xD3,OLED_CMD);//-set display offset	Shift Mapping RAM Counter (0x00~0x3F)
    My_OLED_WriteByte(0x00,OLED_CMD);//-not offset
    My_OLED_WriteByte(0xD5,OLED_CMD);//--set display clock divide ratio/oscillator frequency
    My_OLED_WriteByte(0x80,OLED_CMD);//--set divide ratio
    My_OLED_WriteByte(0xD9,OLED_CMD);//--set pre-charge period
    My_OLED_WriteByte(0xF1,OLED_CMD);//Set Pre-Charge as 15 Clocks & Discharge as 1 Clock
    My_OLED_WriteByte(0xDA,OLED_CMD);//--set com pins hardware configuration
    My_OLED_WriteByte(0x12,OLED_CMD);
    My_OLED_WriteByte(0xDB,OLED_CMD);//--set vcomh
    My_OLED_WriteByte(0x40,OLED_CMD);//Set VCOM Deselect Level
    My_OLED_WriteByte(0x20,OLED_CMD);//-Set Page Addressing Mode (0x00/0x01/0x02)
    My_OLED_WriteByte(0x02,OLED_CMD);//
    My_OLED_WriteByte(0x8D,OLED_CMD);//--set Charge Pump enable/disable
    My_OLED_WriteByte(0x14,OLED_CMD);//--set(0x10) disable
    My_OLED_WriteByte(0xA4,OLED_CMD);//Disable Entire Display On (0xa4/a5)
    My_OLED_WriteByte(0xA6,OLED_CMD);// Disable Inverse Display On (0xa6/a7) 
    My_OLED_WriteByte(0xAF,OLED_CMD);//--turn on oled panel

    My_OLED_WriteByte(0xAF,OLED_CMD); /*display ON*/ 
    My_OLED_Clear();
    My_OLED_SetPos(0,0); 
    My_OLED_Clear();//清屏
    My_OLED_DisplayOff();//关闭显示
    My_OLED_DisplayOn();//打开显示
    My_OLED_Clear();//清屏
}


//	My_OLED_ShowPicture(10,1,42,3,BMP2);

//x0,y0：起点坐标x:0-128 y:0-7(此处由oled屏结构决定 分0-7页)
//x1,y1：终点坐标 x(0-128) y(0-8) 此处判断时没有等于到128 和 8 
//BMP[]：要写入的图片数组 图片像素范围128*64 其中64竖向高最好是8的倍数 如0 8 16 32 40 48 56 64
void My_OLED_ShowPicture(u8 x0,u8 y0,u8 width,u8 high,u8 BMP[])
{
	u32 j=0;
	u8 x=0,y=0;
	if(width>128 || high>64) return;//图片太大
	high = high/8; //oled 每页8个点 共0-7页 此处点转化页位置
	for(y=y0;y<high+y0;y++)
	 {//**All notes can be deleted and modified**//
		 My_OLED_SetPos(x,y);
		 for(x=x0;x<width+x0;x++)
		 {
			 My_OLED_WriteByte(BMP[j++],OLED_DATA);
		}
	 }
}

