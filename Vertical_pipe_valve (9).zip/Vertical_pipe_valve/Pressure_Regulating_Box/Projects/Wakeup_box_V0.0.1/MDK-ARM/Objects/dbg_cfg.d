./objects/dbg_cfg.o: ..\..\..\Middle\dbg_cfg.c ..\..\..\Middle\dbg_cfg.h \
  ..\..\..\..\portable\dbg\dbg.h ..\..\..\Middle\eeprom_config.h \
  ..\..\..\Middle\app_config.h ..\..\..\Middle\threshold.h \
  ..\..\..\Middle\config_store.h ..\..\..\Drivers\at24c64.h
