./objects/dbg.o: ..\..\..\..\portable\dbg\dbg.c \
  ..\..\..\..\portable\dbg\dbg.h
