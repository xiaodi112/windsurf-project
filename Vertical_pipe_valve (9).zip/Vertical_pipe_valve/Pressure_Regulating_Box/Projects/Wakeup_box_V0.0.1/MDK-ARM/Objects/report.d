./objects/report.o: ..\..\..\Middle\report.c ..\..\..\Middle\report.h \
  ..\..\..\Middle\threshold.h ..\..\..\Middle\app_config.h \
  ..\..\..\Middle\ch4_alarm.h ..\..\..\Drivers\ch4_sensor.h \
  ..\..\..\Drivers\ec800e.h \
  ..\..\..\..\GD32L23x_Firmware_Library\CMSIS\GD\GD32L23x\Include\gd32l23x.h \
  D:\keil\pack\ARM\CMSIS\5.3.0\CMSIS\Include\core_cm23.h \
  ..\..\..\..\GD32L23x_Firmware_Library\CMSIS\GD\GD32L23x\Include\system_gd32l23x.h \
  ..\gd32l23x_libopt.h \
  ..\..\..\..\GD32L23x_Firmware_Library\GD32L23x_standard_peripheral\Include\gd32l23x_adc.h \
  ..\..\..\..\GD32L23x_Firmware_Library\GD32L23x_standard_peripheral\Include\gd32l23x_crc.h \
  ..\..\..\..\GD32L23x_Firmware_Library\GD32L23x_standard_peripheral\Include\gd32l23x_cau.h \
  ..\..\..\..\GD32L23x_Firmware_Library\GD32L23x_standard_peripheral\Include\gd32l23x_dac.h \
  ..\..\..\..\GD32L23x_Firmware_Library\GD32L23x_standard_peripheral\Include\gd32l23x_dbg.h \
  ..\..\..\..\GD32L23x_Firmware_Library\GD32L23x_standard_peripheral\Include\gd32l23x_dma.h \
  ..\..\..\..\GD32L23x_Firmware_Library\GD32L23x_standard_peripheral\Include\gd32l23x_exti.h \
  ..\..\..\..\GD32L23x_Firmware_Library\GD32L23x_standard_peripheral\Include\gd32l23x_fmc.h \
  ..\..\..\..\GD32L23x_Firmware_Library\GD32L23x_standard_peripheral\Include\gd32l23x_gpio.h \
  ..\..\..\..\GD32L23x_Firmware_Library\GD32L23x_standard_peripheral\Include\gd32l23x_syscfg.h \
  ..\..\..\..\GD32L23x_Firmware_Library\GD32L23x_standard_peripheral\Include\gd32l23x_i2c.h \
  ..\..\..\..\GD32L23x_Firmware_Library\GD32L23x_standard_peripheral\Include\gd32l23x_fwdgt.h \
  ..\..\..\..\GD32L23x_Firmware_Library\GD32L23x_standard_peripheral\Include\gd32l23x_pmu.h \
  ..\..\..\..\GD32L23x_Firmware_Library\GD32L23x_standard_peripheral\Include\gd32l23x_rcu.h \
  ..\..\..\..\GD32L23x_Firmware_Library\GD32L23x_standard_peripheral\Include\gd32l23x_ctc.h \
  ..\..\..\..\GD32L23x_Firmware_Library\GD32L23x_standard_peripheral\Include\gd32l23x_rtc.h \
  ..\..\..\..\GD32L23x_Firmware_Library\GD32L23x_standard_peripheral\Include\gd32l23x_spi.h \
  ..\..\..\..\GD32L23x_Firmware_Library\GD32L23x_standard_peripheral\Include\gd32l23x_timer.h \
  ..\..\..\..\GD32L23x_Firmware_Library\GD32L23x_standard_peripheral\Include\gd32l23x_usart.h \
  ..\..\..\..\GD32L23x_Firmware_Library\GD32L23x_standard_peripheral\Include\gd32l23x_lpuart.h \
  ..\..\..\..\GD32L23x_Firmware_Library\GD32L23x_standard_peripheral\Include\gd32l23x_wwdgt.h \
  ..\..\..\..\GD32L23x_Firmware_Library\GD32L23x_standard_peripheral\Include\gd32l23x_misc.h \
  ..\..\..\..\GD32L23x_Firmware_Library\GD32L23x_standard_peripheral\Include\gd32l23x_cmp.h \
  ..\..\..\..\GD32L23x_Firmware_Library\GD32L23x_standard_peripheral\Include\gd32l23x_trng.h \
  ..\..\..\..\GD32L23x_Firmware_Library\GD32L23x_standard_peripheral\Include\gd32l23x_slcd.h \
  ..\..\..\..\GD32L23x_Firmware_Library\GD32L23x_standard_peripheral\Include\gd32l23x_lptimer.h \
  ..\..\..\..\GD32L23x_Firmware_Library\GD32L23x_standard_peripheral\Include\gd32l23x_vref.h \
  ..\..\..\Drivers\PT_304_35.h ..\..\..\Drivers\soft_i2c.h \
  ..\..\..\BSP\delay.h ..\..\..\Middle\sensor_record.h \
  ..\..\..\Middle\eeprom_config.h ..\..\..\Middle\main.h \
  ..\..\..\Middle\ota_info.h ..\..\..\BSP\adc_bat.h ..\..\..\App\valve.h \
  ..\..\..\BSP\tim.h ..\..\..\Middle\json_builder.h ..\..\..\BSP\usart.h
