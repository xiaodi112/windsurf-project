.\objects\startup_gd32l235.o: ..\..\..\..\GD32L23x_Firmware_Library\CMSIS\GD\GD32L23x\Source\ARM\startup_gd32l235.s
