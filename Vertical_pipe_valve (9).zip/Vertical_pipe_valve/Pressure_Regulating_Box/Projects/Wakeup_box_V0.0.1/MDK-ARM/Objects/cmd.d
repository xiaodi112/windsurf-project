./objects/cmd.o: ..\..\..\..\portable\cmd\cmd.c \
  ..\..\..\..\portable\cmd\cmd.h ..\..\..\..\portable\dbg\dbg.h
