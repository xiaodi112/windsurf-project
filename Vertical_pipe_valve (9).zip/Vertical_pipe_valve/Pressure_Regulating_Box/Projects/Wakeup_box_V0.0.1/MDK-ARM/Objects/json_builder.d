./objects/json_builder.o: ..\..\..\Middle\json_builder.c \
  ..\..\..\Middle\json_builder.h
