./objects/gd32l23x_rcu.o: \
  ..\..\..\GD32L23x_Firmware_Library\GD32L23x_standard_peripheral\Source\gd32l23x_rcu.c \
  ..\..\..\GD32L23x_Firmware_Library\GD32L23x_standard_peripheral\Include\gd32l23x_rcu.h \
  ..\..\..\GD32L23x_Firmware_Library\CMSIS\GD\GD32L23x\Include\gd32l23x.h \
  D:\keil\pack\ARM\CMSIS\5.3.0\CMSIS\Include\core_cm23.h \
  ..\..\..\GD32L23x_Firmware_Library\CMSIS\GD\GD32L23x\Include\system_gd32l23x.h \
  gd32l23x_libopt.h \
  ..\..\..\GD32L23x_Firmware_Library\GD32L23x_standard_peripheral\Include\gd32l23x_fmc.h \
  ..\..\..\GD32L23x_Firmware_Library\GD32L23x_standard_peripheral\Include\gd32l23x_gpio.h \
  ..\..\..\GD32L23x_Firmware_Library\GD32L23x_standard_peripheral\Include\gd32l23x_misc.h \
  ..\..\..\GD32L23x_Firmware_Library\GD32L23x_standard_peripheral\Include\gd32l23x_usart.h
