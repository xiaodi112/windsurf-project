.\objects\startup_gd32l233.o: ..\..\..\GD32L23x_Firmware_Library\CMSIS\GD\GD32L23x\Source\ARM\startup_gd32l233.s
