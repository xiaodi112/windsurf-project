# ---OTA-httpOTA---m24
GD32
两路传感器
低功耗
蓝牙
cat1
2026-7-18
