#ifndef MYSYSTICK_DELAY_H
#define MYSYSTICK_DELAY_H


#include "gd32l23x.h"  // GD32L233��׼��ͷ�ļ�

#define IIC_WR    0     /* д����bit */
#define IIC_RD    1     /* ������bit */

void IIC_Start(void);
void IIC_Stop(void);
void IIC_Send_Byte(uint8_t _ucByte);
uint8_t IIC_Read_Byte(uint8_t ack);
uint8_t IIC_Wait_Ack(void);
void IIC_Ack(void);
void IIC_NAck(void);
uint8_t IIC_CheckDevice(uint8_t _Address);
void IIC_GPIO_Init(void);



#endif
