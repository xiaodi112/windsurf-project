#ifndef MYSYSTICK_DELAY_H
#define MYSYSTICK_DELAY_H

#include <stdint.h>

/*Systick---CLKSOURCE*/
void my_systick_config(void);

/*ms*/
void my_systick_delay_ms(uint32_t counts);

/*us*/
void my_systick_delay_us(uint32_t counts);



#endif
