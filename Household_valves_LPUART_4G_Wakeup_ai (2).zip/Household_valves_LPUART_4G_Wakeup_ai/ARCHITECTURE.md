# 家用阀门物联网控制器 — 工程架构文档

> MCU: GD32L233R (Cortex-M23, 低功耗)
> 4G模块: EC801E (Cat.1, AT指令)
> MQTT平台: FastBee (120.78.220.171:1883)

---

## 一、整体架构

```
  ┌──────────────────────────────────────────────────────────┐
  │                    GD32L233R MCU                          │
  │                                                          │
  │  main.c 状态机                                           │
  │  ┌─────────┐  ┌──────────┐  ┌──────────┐  ┌──────────┐  │
  │  │  INIT   │→│  SLEEP   │→│ WAKEUP   │→│ COLLECT  │  │
  │  └─────────┘  └──────────┘  └──────────┘  └────┬─────┘  │
  │                     ↑                          │         │
  │                     │    ┌──────────┐  ┌───────▼──────┐  │
  │                     └────│DOWNLINK  │←│  UPLOAD     │  │
  │                          └──────────┘  └──────────────┘  │
  │                                                          │
  │  USART0(PC4/PC5)  ←→  Debug串口 (115200)                │
  │  LPUART0(PA2/PA3) ←→  EC801E 4G模块 (115200)           │
  │  I2C-1(PB6/PB7)   ←→  PT304D 压力温度传感器              │
  │  I2C-2(PB8/PB9)   ←→  AT24C16 EEPROM                   │
  │  ADC(PA5)          ←   电池电压 (2M+2M分压)              │
  │  TIMER2(PA6/PA7)   →   电机PWM (CH0正转/CH1反转)         │
  │  GPIO(PC0)         →   电机使能                          │
  │  GPIO(PC1/PC2)     ←   电机到位信号 (低电平=到位)         │
  │  GPIO(PD4)         →   电子开关控制                      │
  │  GPIO(PD9)         →   4G模块电源开关 (HIGH=供电,LOW=断电)│
  └──────────────────────────────────────────────────────────┘
```

### 当前架构关键特征

**QSCLK持久连接:**
- **PD9 是4G模块电源开关**（控制MOS管/LDO使能），休眠时保持HIGH
- **模块QSCLK=2轻休眠**(~1-3mA)，保持网络+MQTT连接+订阅
- **上报无需重连**：EnsureConnected检查→直接Publish (~1-2s)
- **MQTT下发可用**：模块缓存(recv/mode=1) + LPUART唤醒MCU + AT+QMTRECV主动查询
- **双唤醒源**：RTC闹钟(定时采集) + LPUART(下发消息/断线通知)

**数据采集与存储:**
- **RAM环形缓冲区**：每次采集存入记录(压力+温度+电压+时间戳)，深休眠保持SRAM
- **阈值监测**：压力/电压上下限 + 突变检测，异常5次重采确认后触发报警
- **报警立即上报**：确认异常后立即唤醒4G → debug打印 + MQTT发布报警消息

**批量数据上报:**
- **逐条上传**：到达上报周期时，缓冲区中每条记录逐条发布(间隔1秒)
- **上传后清空**：本周期数据全部上传完成后清空缓冲区

**下发实时响应 (最高优先级):**
- **阀门控制/传感器读取指令 → 立即执行 → 立即上报结果**
- **平台可远程修改**：采集/上报周期、心跳、阈值等配置
- 延迟 ~3-5秒 (LPUART唤醒→查询→执行→上报)

---

## 二、引脚分配

| 引脚 | 外设/模式 | 功能 |
|------|----------|------|
| PA2  | LPUART0 TX (AF8) | 发送AT指令到EC801E |
| PA3  | LPUART0 RX (AF8) | 接收EC801E应答/下发URC, 深休眠唤醒源 |
| PA5  | ADC CH5 模拟输入 | 电池电压采集 (VIN×2M/(2M+2M)) |
| PA6  | TIMER2 CH0 (AF1) | 电机PWM通道A (正转) |
| PA7  | TIMER2 CH1 (AF1) | 电机PWM通道B (反转) |
| PB6  | GPIO软件I2C SCL | PT304D传感器时钟线 |
| PB7  | GPIO软件I2C SDA | PT304D传感器数据线 |
| PB8  | GPIO软件I2C SCL | AT24C16 EEPROM时钟线 |
| PB9  | GPIO软件I2C SDA | AT24C16 EEPROM数据线 |
| PC0  | GPIO推挽输出 | 电机使能 (HIGH=开, LOW=关) |
| PC1  | GPIO上拉输入 | 电机到位信号1 (LOW=到位) |
| PC2  | GPIO上拉输入 | 电机到位信号2 (LOW=到位) |
| PC4  | USART0 TX (AF7) | Debug调试串口发送 |
| PC5  | USART0 RX (AF7) | Debug调试串口接收, 配置命令输入 |
| PD4  | GPIO推挽输出 | 电子开关控制 |
| PD9  | GPIO推挽输出 | 4G模块电源开关 (HIGH=供电, 休眠时保持HIGH) |

---

## 三、状态机详解

### 3.1 状态流转图

```
                        ┌───────── 上电 ─────────┐
                        ▼                        │
                  ┌───────────┐                  │
                  │ STATE_INIT│ (只执行一次)       │
                  └─────┬─────┘                  │
                        │                        │
              ┌─────────▼──────────┐             │
              │   STATE_SLEEP      │◄────────────┤
              │ PC0=0,PD4=0        │◄──────┐     │
              │ PD9保持HIGH(QSCLK) │       │     │
              │ RTC闹钟+LPUART唤醒  │       │     │
              └──┬──────────┬──────┘       │     │
       LPUART唤醒│          │RTC闹钟       │     │
       (counter0)│          │(rtc_alarm)   │     │
              ┌──▼──────────▼──────┐       │     │
              │   STATE_WAKEUP     │       │     │
              │ system_wakeup_reinit│       │     │
              │ sys_init (恢复外设) │       │     │
              └──┬──────────┬──────┘       │     │
                 │          │              │     │
        ┌────────▼───┐  ┌──▼──────────┐    │     │
        │ DOWNLINK   │  │  COLLECT     │    │     │
        │★最高优先级  │  │ 采集+存入缓冲 │    │     │
        │ 执行+立即   │  │ 阈值检查      │    │     │
        │ 上报结果    │  └─┬────┬───┬──┘    │     │
        └─────┬──────┘    │    │   │       │     │
              │     正常   │    │   │异常    │     │
              │     count++│    │   │       │     │
              │           │    │   ▼       │     │
              │           │    │ STATE_ALARM│     │
              │           │    │ 重采5次确认 │     │
              │           │    │ debug+4G报警│     │
              │           │    │           │     │
              │    count<N│    │count≥N    │     │
              │           │  ┌─▼────────┐  │     │
              │           │  │ UPLOAD    │  │     │
              │           │  │ 逐条上传   │  │     │
              │           │  │ 1秒/条    │  │     │
              │           │  │ 完成清空   │  │     │
              │           │  └─────┬────┘  │     │
              │           │        │       │     │
              └───────────┴────────┴───────┘     │
                        全部回到 SLEEP ───────────┘
```

### 3.2 各状态职责

#### STATE_INIT (main函数, 上电执行一次)
```
sys_init()                  → SysTick + Debug串口 + GPIO + I2C×2 + ADC
                               PD9=1(给4G模块供电), PD4=1, PC0=1
config_load_all()           → 从AT24C16加载间隔+MQTT+阈值配置
config_enter_setup_mode(2)  → 2秒窗口: 收到"reset"则强制重配
rtc_init_all()              → RTC + LXTAL时钟源
sensor_buf_init()           → 初始化RAM环形缓冲区 (magic校验, 防止上电脏数据)
EC801E_PowerOn()            → PD9低600ms→高, 等3s (断电→上电)
EC801E_InitAndConnect()     → 注网+MQTT连接+订阅+同步时间+QSCLK=2
  InitNetwork流程: AT→CPIN?→QCCID(打印ICCID)→CSQ→CGACT
  包含: recv/mode=1(缓存) + SubscribeTopic(下发订阅) + keepalive(从EEPROM)
首次采集+存入缓冲+发布     → PT304D + ADC + 存入buffer + Publish
EC801E_SetPSM(1)            → 启用QSCLK=2
```

#### STATE_SLEEP (do_sleep)
```
关闭外设:
  PC0=0 (电机使能关)
  PD4=0 (电子开关关)
  PD9保持HIGH (模块QSCLK=2自动休眠, 保持网络+MQTT)
RTC闹钟: collect_interval_min 分钟后唤醒
LPUART唤醒: 起始位检测 (EXTI28上升沿)
  → 模块收到MQTT下发时发URC触发唤醒
WFI深休眠: PMU_LDNPDSP_LOWDRIVE
  → MCU ~μA + EC801E QSCLK ~1-3mA
  → 双唤醒源: RTC闹钟 + LPUART
```

#### STATE_WAKEUP (do_wakeup)
```
system_wakeup_reinit()  → 恢复IRC16M时钟, 关闭LPUART唤醒中断
                           LPUART唤醒时: 消费首字节 + 禁用LPUART(后URC字节丢失)
sys_init()              → 恢复全部外设 (PD9已是HIGH, 模块一直在运行)
判断唤醒源:
  counter0 ≠ 0  → STATE_DOWNLINK (MQTT下发触发)
  rtc_alarm_flag → STATE_COLLECT  (定时采集)
  其他           → STATE_COLLECT  (兜底)
```

#### STATE_COLLECT (do_collect)
```
PT304D_Collect()            → I2C读取压力+温度
adc_bat_read_voltage()      → ADC读取电池电压
rtc_get_time_str()          → 获取当前时间戳

阈值检查:
  上下限: pressure∈[pmin,pmax], voltage∈[vmin,vmax]
  突变:  |pressure - last_pressure| > mutation_delta

正常路径:
  sensor_buf_push(record)   → 存入RAM环形缓冲区 (数据+时间戳)
  wakeup_count++
  count ≥ upload_every_n ?  → STATE_UPLOAD : STATE_SLEEP

异常路径:
  → STATE_ALARM             → 进入报警确认流程
```

#### STATE_UPLOAD (do_upload)
```
com_lpuart_init()                 → 重新初始化LPUART
EC801E_EnsureConnected()          → AT唤醒 + QMTCONN?检查连接
  正常: state=3 → 直接Publish | 异常: InitAndConnect重连

批量逐条上传:
  n = sensor_buf_count()
  for(i = 0; i < n; i++):
    record = sensor_buf_get(i)
    PublishSingleRecord(record)   → 该记录的数据 + 该记录的时间戳
    delay(1000)                   → 每条间隔1秒, 保证服务器接收有效

sensor_buf_clear()                → 上传完成, 清空缓冲区
wakeup_count = 0
EC801E_SetPSM(1)                  → 重新启用QSCLK=2
→ STATE_SLEEP

注: N条记录上传耗时~N秒, keepalive=300s内不会断线
```

#### STATE_DOWNLINK (do_downlink) ★最高优先级
```
com_lpuart_init()           → 重新初始化LPUART
EC801E_ReadDownlink()       → 唤醒模块 + AT+QMTRECV=0主动查询
  成功: 解析FastBee JSON [{"id":"xxx","value":"xxx"}]
  失败: 可能是+QMTSTAT断线通知 → EnsureConnected重连

指令分发 (id字段):
  "valve"             → 阀门控制(open/close) + 立即Publish结果
  "sensor_read"       → 立即采集传感器 + 立即Publish当前值
  "collect_interval"  → 修改采集周期 → 保存EEPROM + 重算参数
  "upload_interval"   → 修改上报周期 → 保存EEPROM + 重算参数
  "keepalive"         → 修改心跳 → AT+QMTCFG + 保存EEPROM
  "threshold"         → 修改阈值 → 保存EEPROM

阀门控制流程 (执行后立即上报):
  "open"/"1"  → PC0使能 + PWM(160kHz) CH0=80%(正转) + 等PC1到位(≤10s) + 停止
  "close"/"0" → PC0使能 + PWM(160kHz) CH1=80%(反转) + 等PC2到位(≤10s) + 停止
  → Publish [{"id":"valve","value":"open_ok"/"close_ok"/"timeout"}]

传感器读取流程 (立即采集并上报):
  PT304D_Collect() + adc_bat_read_voltage()
  → Publish [{"id":"pressure","value":"xx"},{"id":"temp",...},{"id":"voltage",...}]

EC801E_SetPSM(1)            → 重新启用QSCLK=2
→ STATE_SLEEP
```

#### STATE_ALARM (do_alarm) — 由COLLECT异常触发
```
触发条件: do_collect中检测到阈值超限或突变

确认流程:
  for(i = 0; i < 5; i++):
    delay(500)               → 间隔0.5秒重新采集
    PT304D_Collect() + ADC
    如果恢复正常 → break, 当作偶发抖动
  5次全部异常 → 确认报警

报警输出 (双通道):
  1. printf_debug() → Debug串口打印报警详情
  2. com_lpuart_init() → EnsureConnected()
     → PublishAlarm()  → [{"id":"alarm","value":"pressure_high",...}]

存入缓冲区: sensor_buf_push(record, flags=ALARM)
EC801E_SetPSM(1)
→ STATE_SLEEP

偶发抖动 (重采中恢复正常):
  不报警, 正常存入缓冲区, 按原流程继续
```

---

## 四、文件结构与职责

```
07_LPUART_Deepsleep_Wakeup/
├── main.c                  ← 状态机主程序 (7个状态: +ALARM)
├── gd32l23x_it.c           ← 中断服务: SysTick→trea_time_isr(), RTC闹钟, LPUART唤醒
├── MDK-ARM/
│   └── my_Library/
│       ├── 【通信层】
│       │   ├── usart.c/h       ← USART0调试口 + LPUART0(4G通信)
│       │   │                      printf_debug() / printf_cat1()
│       │   │                      LPUART唤醒初始化 / 深休眠进入 / 唤醒恢复
│       │   ├── ec800e.c/h      ← EC801E AT指令驱动
│       │   │                      电源 / 网络 / MQTT连接+发布+订阅
│       │   │                      QSCLK / 下发读取 / 断线重连 / 报警发布
│       │   └── app_config.h    ← 编译时默认值 (MQTT/超时/keepalive/阈值)
│       │
│       ├── 【存储层】
│       │   ├── eeprom_config.c/h ← AT24C16配置管理
│       │   │                        EEPROM布局 / 加载 / 保存 / Debug串口配置
│       │   │                        新增: 阈值+心跳配置存取
│       │   ├── AT24c16.c/h       ← AT24C16底层读写 (I2C-2: PB8/PB9)
│       │   └── i2c_cz.c/h       ← 软件I2C-2 (PB8=SCL, PB9=SDA)
│       │
│       ├── 【数据层】 (新增)
│       │   ├── sensor_buffer.c/h ← RAM环形缓冲区
│       │   │                        init / push / get / count / clear
│       │   │                        深休眠保持SRAM, magic校验防脏数据
│       │   └── threshold.c/h     ← 阈值检查模块
│       │                              上下限判断 / 突变检测 / EEPROM存取
│       │
│       ├── 【传感器层】
│       │   ├── PT_304_35.c/h   ← PT304D压力温度传感器驱动
│       │   │                      I2C地址0x00, 0xAA触发, 7字节读取
│       │   ├── myi2c.c/h       ← 软件I2C-1 (PB6=SCL, PB7=SDA)
│       │   └── adc_bat.c/h     ← 电池电压ADC (PA5, CH5, ×2分压)
│       │
│       ├── 【执行器层】
│       │   ├── motor.c/h       ← TIMER2双通道PWM (PA6=CH0, PA7=CH1)
│       │   │                      pwm_init() / pwm_set_duty() / pwm_set_freq()
│       │   └── mygpio.c/h      ← GPIO初始化 + 电机到位信号读取
│       │                          PC0使能, PC1/PC2到位, PD4/PD9输出
│       │
│       ├── 【时间层】
│       │   ├── tim.c/h         ← RTC (LXTAL 32.768kHz)
│       │   │                      初始化 / 闹钟唤醒 / CCLK时间解析+设置
│       │   └── delay.c/h       ← SysTick毫秒计时
│       │                          trea_millis() / trea_delay_ms() / delay_us()
│       │
│       └── main.h              ← Flash/OTA相关定义
```

---

## 五、MQTT通信架构

### 5.1 连接策略: QSCLK=2 持久连接

```
上电一次: 注网 → MQTT连接 → 订阅 → recv/mode=1 → QSCLK=2
上报时: AT唤醒 → 检查连接(state=3) → 直接Publish → QSCLK=2
  ~1-2秒/次, 可接收下发

模块QSCLK=2行为:
  - UART空闲时自动进入轻休眠 (~1-3mA)
  - 每 keepalive 秒自动发PINGREQ心跳维持MQTT
  - 收到服务器消息自动唤醒, 缓存消息 + 发URC通知
  - URC触发MCU LPUART唤醒
```

### 5.2 MQTT参数

| 参数 | 默认值 | 存储位置 | 可配置 |
|------|--------|----------|--------|
| Server | 120.78.220.171 | EEPROM 0x0E3 | Debug串口 |
| Port | 1883 | EEPROM 0x0E1 | Debug串口 |
| ClientID | S&D54GRG29T5HB0&149&1 | EEPROM 0x021 | Debug串口 |
| Username | FastBee | EEPROM 0x061 | Debug串口 |
| Password | P41TQ4X1Y0C57IW0 | EEPROM 0x0A1 | Debug串口 |
| Topic(上报) | /149/.../property/post | EEPROM 0x123 | Debug串口 |
| Topic(下发) | 从上报topic推导: /property/post→/function/get | 运行时计算 | 自动 |
| Keepalive | 300秒 | EEPROM 0x1B0 | Debug串口 + 平台下发 |

### 5.3 上报数据格式 (FastBee JSON)

**周期采集上报** (逐条发布, 每条带自己的采集时间戳):
```json
[
  {"id":"voltage",  "value":"3.60", "ts":"2026-04-19 10:00:00", "remark":""},
  {"id":"pressure", "value":"12.34","ts":"2026-04-19 10:00:00", "remark":""},
  {"id":"temp",     "value":"25.30","ts":"2026-04-19 10:00:00", "remark":""}
]
```

**报警上报** (确认异常后立即发布):
```json
[
  {"id":"alarm",    "value":"pressure_high", "ts":"2026-04-19 10:05:00", "remark":"P=36.5"},
  {"id":"pressure", "value":"36.50",          "ts":"2026-04-19 10:05:00", "remark":""},
  {"id":"voltage",  "value":"3.55",           "ts":"2026-04-19 10:05:00", "remark":""}
]
```

**下发响应上报** (执行结果反馈):
```json
[{"id":"valve", "value":"open_ok"}]
[{"id":"valve", "value":"close_timeout"}]
```

### 5.4 下发命令格式 (FastBee JSON)

**执行类指令** (立即执行 + 立即上报结果):
```json
[{"id":"valve",       "value":"open"}]
[{"id":"valve",       "value":"close"}]
[{"id":"sensor_read", "value":"1"}]
```

**配置类指令** (修改参数 + 保存EEPROM):
```json
[{"id":"collect_interval", "value":"0.5"}]
[{"id":"upload_interval",  "value":"2.0"}]
[{"id":"keepalive",        "value":"120"}]
[{"id":"threshold",        "value":"pmin:0.5,pmax:35,vmin:3.0,vmax:4.2,mutation:0.5"}]
```

---

## 六、数据存储架构

### 6.1 RAM环形缓冲区 (sensor_buffer)

```
存储介质: GD32L233R SRAM (32KB, 深休眠保持不丢失)
放置方式: .noinit段 或 __attribute__((section(".noinit")))
         防止startup代码清零, 仅在上电时通过magic校验初始化

记录结构 (SensorRecord_t, ~40字节):
  float pressure         4B    压力
  float temperature      4B    温度
  float voltage          4B    电池电压
  char  timestamp[20]    20B   "2026/04/19,10:00:00"
  uint8_t flags          1B    bit0=ALARM(报警记录)
  uint8_t reserved[7]    7B    对齐到40字节

缓冲区容量: 128条 × 40B = 5120B (~5KB)

接口:
  sensor_buf_init()      → 上电时调用, 校验magic, 无效则清零
  sensor_buf_push()      → 写入一条记录 (满则覆盖最早的)
  sensor_buf_get(i)      → 读取第i条记录
  sensor_buf_count()     → 当前记录数
  sensor_buf_clear()     → 清空缓冲区 (上报完成后调用)
```

### 6.2 阈值配置 (ThresholdConfig_t)

```
存储介质: EEPROM (AT24C16, 掉电不丢失)

结构体:
  float pressure_min      压力下限 (kPa)
  float pressure_max      压力上限 (kPa)
  float voltage_min       电压下限 (V)
  float voltage_max       电压上限 (V)
  float mutation_delta    突变阈值 (与上次采集的差值)

检查逻辑 (threshold_check):
  超限: pressure < pmin || pressure > pmax || voltage < vmin || voltage > vmax
  突变: |pressure - last_pressure| > mutation_delta
  返回: THRESHOLD_OK / THRESHOLD_OVER_LIMIT / THRESHOLD_MUTATION

配置渠道:
  1. Debug串口: {pmin:0.5,pmax:35,vmin:3.0,vmax:4.2,mutation:0.5}
  2. 平台下发: [{"id":"threshold","value":"pmin:0.5,pmax:35,..."}]
```

---

## 七、低功耗设计

### 7.1 功耗分布

| 状态 | MCU | EC801E | 总计(估) |
|------|-----|--------|--------|
| 深休眠 | ~μA | QSCLK ~1-3mA | ~1-3mA |
| 每 keepalive 心跳 | 不唤醒MCU | ~100-300ms活跃 | 脉冲 |
| 采集(不上报) | ~10mA, ~100ms | QSCLK | 短暂 |
| 单条上报 | ~10mA, ~1-2s | ~100mA, ~1-2s | 短暂 |
| 批量上报(N条) | ~10mA, ~N秒 | ~100mA, ~N秒 | N条×1秒 |
| 报警(5次重采+上报) | ~10mA, ~5s | ~100mA, ~2s | ~5-7s |
| 下发响应(执行+上报) | ~10mA, ~3-5s | ~100mA, ~2s | ~3-5s |
| 阀门动作 | ~10mA, ≤10s | QSCLK | 电机另计 |

### 7.2 休眠进入流程
```
do_sleep()
  ├─ gpio_bit_reset(PC0)   关电机使能
  ├─ gpio_bit_reset(PD4)   关电子开关
  ├─ PD9保持HIGH          模块QSCLK=2自动休眠
  ├─ rtc_set_next_alarm()  设RTC闹钟
  ├─ lpuart_wakeup_init()  配LPUART起始位唤醒 (模块URC可触发)
  └─ enter_deepsleep_mode()
       ├─ counter0 = 0, rtc_alarm_flag = 0
       ├─ PMU深休眠 (WFI)
       └─ 唤醒: RTC闹钟 或 LPUART(counter0)
```

### 7.3 唤醒恢复流程
```
do_wakeup()
  ├─ system_wakeup_reinit()
  │    ├─ IRC16M重启
  │    ├─ SysTick重配
  │    ├─ 关LPUART唤醒中断
  │    └─ 消费唤醒字节(防中断持续触发)
  ├─ sys_init()
  │    ├─ systick_config() + my_systick_config()
  │    ├─ trea_uart_init()     (Debug串口)
  │    ├─ gpio_init() + motor_init()
  │    ├─ IIC_Init() + IIC_GPIO_Init1()  (两条I2C)
  │    ├─ adc_bat_init()
  │    └─ PD9已HIGH(模块一直运行), PD4=1, PC0=1
  └─ 判断唤醒源 → COLLECT或DOWNLINK
```

---

## 八、配置系统

### 8.1 EEPROM布局 (AT24C16, 2048字节)

```
地址        长度    内容                        可配置渠道
───────────────────────────────────────────────────────────
【间隔配置】
0x000       1      间隔 Magic (0xA5=有效)         -
0x001-0x004 4      采集周期 (float, 小时)        Debug串口 + 平台下发
0x005-0x008 4      上报周期 (float, 小时)        Debug串口 + 平台下发

【MQTT配置】
0x020       1      MQTT Magic (0x5A=有效)         -
0x021-0x060 64     ClientID                      Debug串口
0x061-0x0A0 64     Username                      Debug串口
0x0A1-0x0E0 64     Password                      Debug串口
0x0E1-0x0E2 2      Port (uint16_t)               Debug串口
0x0E3-0x122 64     Server IP                     Debug串口
0x123-0x1A2 128    Topic(上报)                    Debug串口

【阈值+心跳配置】 (新增)
0x1B0       1      阈值 Magic (0xC3=有效)         -
0x1B1-0x1B4 4      压力下限 (float, kPa)          Debug串口 + 平台下发
0x1B5-0x1B8 4      压力上限 (float, kPa)          Debug串口 + 平台下发
0x1B9-0x1BC 4      电压下限 (float, V)            Debug串口 + 平台下发
0x1BD-0x1C0 4      电压上限 (float, V)            Debug串口 + 平台下发
0x1C1-0x1C4 4      突变阈值 (float, kPa)         Debug串口 + 平台下发
0x1C5-0x1C6 2      Keepalive (uint16_t, 秒)       Debug串口 + 平台下发
0x1C7-0x1FF 57     预留

已用: ~0x1C7/2048 = ~455/2048, 剩余~1593字节
```

### 8.2 配置流程 (上电时)

```
config_load_all()  → 从EEPROM读取间隔+MQTT+阈值, 无效则用默认值
config_enter_setup_mode(2秒):
  ├─ 2秒内收到"reset" → 强制重配(清除Magic, 等待串口输入)
  ├─ 2秒内无"reset":
  │    ├─ 所有Magic有效 → 跳过, 直接运行
  │    └─ 某个Magic无效 → 只配置无效的部分
  └─ 配置命令格式:
       间隔: {collect:1,upload:5}
       MQTT: {clientId:xxx,username:xxx,passwd:xxx,port:1883}
       阈值: {pmin:0.5,pmax:35,vmin:3.0,vmax:4.2,mutation:0.5}
       心跳: {keepalive:120}
```

### 8.3 运行时配置修改 (新增)

```
不重启修改配置:
  平台下发: [{"id":"collect_interval","value":"0.5"}]
    → 修改 g_interval → config_save_interval() → config_recalc_interval()
    → 下次休眠时RTC闹钟用新周期

  平台下发: [{"id":"keepalive","value":"120"}]
    → AT+QMTCFG="keepalive",0,120
    → 保存EEPROM
    → 立即生效 (模块下次PINGREQ用新周期)

  平台下发: [{"id":"threshold","value":"pmin:0.5,pmax:35,..."}]
    → 解析子字段 → 修改 g_threshold → config_save_threshold()
    → 下次采集时用新阈值
```

---

## 九、关键函数调用链

### 9.1 初始化路径
```
main() STATE_INIT
  ├→ sys_init()                    外设初始化
  ├→ config_load_all()             加载间隔+MQTT+阈值+心跳
  ├→ sensor_buf_init()             RAM缓冲区 magic校验
  ├→ EC801E_PowerOn()              PD9低→高
  └→ EC801E_InitAndConnect()
       ├→ EC801E_SetPSM(0)          关闭QSCLK
       ├→ EC801E_InitNetwork()       AT→CPIN→CSQ→CGACT
       ├→ QMTCFG keepalive=N        从EEPROM读取
       ├→ QMTCFG recv/mode=1        消息缓存模式
       ├→ EC801E_ConnectMQTT()       QMTOPEN→QMTCONN→验证
       ├→ EC801E_SubscribeTopic()    QMTSUB订阅下发
       ├→ EC801E_SyncTime()          CCLK→RTC
       └→ EC801E_SetPSM(1)          启用QSCLK=2
```

### 9.2 采集+上报路径
```
do_collect()
  ├→ PT304D_Collect()              压力+温度
  ├→ adc_bat_read_voltage()        电池电压
  ├→ rtc_get_time_str()            时间戳
  ├→ threshold_check()             阈值检查
  │    ├→ 正常: sensor_buf_push() → count++ → UPLOAD或SLEEP
  │    └→ 异常: → STATE_ALARM

do_alarm()
  ├→ for(5次): delay(500) + PT304D_Collect() + ADC
  ├→ 全部异常: printf_debug + EnsureConnected + PublishAlarm
  └→ sensor_buf_push(flags=ALARM)

do_upload()
  ├→ EnsureConnected()
  ├→ for(i < buf_count): PublishSingleRecord(i) + delay(1000)
  ├→ sensor_buf_clear()
  └→ SetPSM(1)
```

### 9.3 下发路径
```
MQTT服务器 → EC801E缓存 → URC → LPUART唤醒 → counter0=1

do_downlink()
  ├→ EC801E_ReadDownlink()         AT+QMTRECV=0查询缓存
  ├→ 解析 id/value
  ├→ 指令分发:
  │    ├→ valve   → PWM控制 → Publish结果
  │    ├→ sensor_read → PT304D+ADC → Publish当前值
  │    ├→ collect/upload_interval → 修改+保存EEPROM
  │    ├→ keepalive → AT+QMTCFG + 保存EEPROM
  │    └→ threshold → 解析+保存EEPROM
  ├→ 无消息: EnsureConnected()检测断线重连
  └→ SetPSM(1)
```

---

## 十、注意事项

1. **PD9是电源开关**: `ec800e.h`中`EC_PWRKEY_PIN=GPIO_PIN_9`命名具有误导性。实际为电源开关(控制MOS管/LDO), `EC801E_PowerOn()`的低→高时序 = 断电→上电。

2. **LPUART唤醒后URC丢失**: `system_wakeup_reinit()`消费首字节后`lpuart_disable()`，因此用`recv/mode=1`缓存 + `AT+QMTRECV=0`主动查询。

3. **QSCLK=2唤醒时序**: 首字节可能丢失。`EC801E_Wakeup()`先发AT\r\n等100ms再发正式命令。

4. **+QMTSTAT断线通知**: 模块MQTT断线时也发URC触发LPUART唤醒。`do_downlink()`中若无消息则`EnsureConnected()`重连。

5. **两条独立I2C总线**: I2C-1 (PB6/PB7) → PT304D, I2C-2 (PB8/PB9) → AT24C16 EEPROM。不可混用。

6. **SRAM深休眠保持**: GD32L233R深休眠模式保持SRAM供电。RAM缓冲区放.noinit段防startup清零, 上电时magic校验。

7. **批量上报耗时**: N条记录上传耗时~N秒。需确保keepalive足够大(>最大可能的N)。

8. **下发实时性**: LPUART唤醒→执行→上报 ~3-5秒。counter0优先于rtc_alarm_flag判断，保证最高优先级。

9. **Debug串口配置**: 上电2秒窗口"reset"强制重配。支持间隔/MQTT/阈值/心跳4类配置命令。

10. **电机到位超时**: 阀门动作≤10秒，超时强制停止，上报"timeout"结果。
