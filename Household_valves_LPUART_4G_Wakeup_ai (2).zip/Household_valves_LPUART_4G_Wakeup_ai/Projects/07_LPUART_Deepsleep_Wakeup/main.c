/**
 * @file main.c
 * @brief 家用阀门物联网控制器 — 状态机驱动低功耗主程序
 *
 * 架构: MQTT持久连接 + MCU深休眠 + LPUART唤醒接收下发
 *
 * 状态机 (7个状态):
 *   STATE_INIT     → 上电初始化+MQTT连接+订阅+首次上报 → STATE_SLEEP
 *   STATE_SLEEP    → 设闹钟+深休眠(模块QSCLK保持MQTT) → STATE_WAKEUP
 *   STATE_WAKEUP   → 恢复外设+判断唤醒源:
 *                     RTC闹钟 → STATE_COLLECT
 *                     LPUART  → STATE_DOWNLINK
 *   STATE_COLLECT  → 采集+阈值检查+存入缓冲区 → STATE_UPLOAD/ALARM/SLEEP
 *   STATE_UPLOAD   → 批量逐条上报+清空缓冲区 → STATE_SLEEP
 *   STATE_DOWNLINK → 读取+处理MQTT下发指令+立即上报结果 → STATE_SLEEP
 *   STATE_ALARM    → 5次重采确认+报警上报 → STATE_SLEEP
 */

#include "gd32l23x.h"
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "systick.h"
#include "usart.h"
#include "delay.h"
#include "ec800e.h"
#include "mygpio.h"
#include "tim.h"
#include "PT_304_35.h"
#include "motor.h"
#include "app_config.h"
#include "eeprom_config.h"
#include "AT24c16.h"
#include "main.h"
#include "adc_bat.h"
#include "i2c_cz.h"
#include "sensor_buffer.h"
#include "threshold.h"

// ==================== 状态定义 ====================
typedef enum {
    STATE_INIT = 0,
    STATE_SLEEP,
    STATE_WAKEUP,
    STATE_COLLECT,
    STATE_UPLOAD,
    STATE_DOWNLINK,
    STATE_ALARM
} AppState_t;

// ==================== 全局变量 ====================
PT304D_Data pt304d;
float voltage1 = 0;
float pressure1 = 0;
float temperature1 = 0;

static volatile uint16_t wakeup_count = 0;
static AppState_t app_state = STATE_INIT;
static float last_pressure = -1.0f;   // 上次采集压力 (首次-1跳过突变检测)

// ==================== 硬件恢复 ====================
static void sys_init(void)
{
    systick_config();
    my_systick_config();
    trea_uart_init();

    gpio_init();
    motor_init();
    IIC_Init();
	IIC_GPIO_Init1();
    adc_bat_init();
    gpio_bit_set(GPIOC, GPIO_PIN_0);

    gpio_bit_set(GPIOD, GPIO_PIN_4);
    gpio_bit_set(GPIOD, GPIO_PIN_9);

    trea_delay_ms(100);
}

// ==================== 进入休眠 ====================
static void do_sleep(void)
{
    // 关闭外设降功耗
	gpio_bit_reset(GPIOC, GPIO_PIN_0);
    gpio_bit_reset(GPIOD, GPIO_PIN_4);
//	gpio_bit_reset(GPIOD, GPIO_PIN_9);

    // 设置RTC闹钟（紧贴深休眠前，防止闹钟时间已过）
    rtc_alarm_wakeup_init();
    rtc_set_next_alarm(g_interval.collect_interval_min);

    // 设置LPUART唤醒
    com_lpuart_init();
    lpuart_wakeup_init();

    printf_debug("[SM] SLEEP %dmin (buf=%d)\r\n",
                 g_interval.collect_interval_min, sensor_buf_count());
    trea_delay_ms(20);

    enter_deepsleep_mode();

    // 唤醒后立即转到 WAKEUP 状态
    app_state = STATE_WAKEUP;
}

// ==================== 唤醒恢复 ====================
static void do_wakeup(void)
{
    system_wakeup_reinit();
    sys_init();

    rtc_show_time();
    printf_debug("\r\n");

    // 2秒窗口: 检测debug串口是否收到"reset"指令
    config_check_reset(2000);

    if(counter0)
    {
        printf_debug("[SM] WAKEUP: LPUART (downlink)\r\n");
        app_state = STATE_DOWNLINK;
    }
    else if(rtc_alarm_flag)
    {
        printf_debug("[SM] WAKEUP: RTC\r\n");
        app_state = STATE_COLLECT;
    }
    else
    {
        printf_debug("[SM] WAKEUP: unknown\r\n");
        app_state = STATE_COLLECT;
    }
}

// ==================== 采集传感器 + 阈值检查 ====================
static void do_collect(void)
{
    SensorRecord_t record;
    ThresholdResult_t result;

    PT304D_Collect(&pt304d);
    pressure1 = pt304d.pressure;
    temperature1 = pt304d.temperature;
    voltage1 = adc_bat_read_voltage();

    printf_debug("[SM] COLLECT #%d/%d V=%.2f P=%.2f T=%.2f\r\n",
                 wakeup_count + 1, g_interval.upload_every_n,
                 voltage1, pressure1, temperature1);

    // 阈值检查
    result = threshold_check(pressure1, voltage1, last_pressure);

    if(result != THRESHOLD_OK)
    {
        printf_debug("[SM] THRESHOLD ABNORMAL (%d), entering ALARM\r\n", result);
        app_state = STATE_ALARM;
        return;
    }

    // 正常: 存入缓冲区
    record.pressure = pressure1;
    record.temperature = temperature1;
    record.voltage = voltage1;
    rtc_get_time_str(record.timestamp, sizeof(record.timestamp));
    record.flags = 0;
    memset(record.reserved, 0, sizeof(record.reserved));

    sensor_buf_push(&record);
    last_pressure = pressure1;
    wakeup_count++;

    // 判断是否需要上报
    if(wakeup_count >= g_interval.upload_every_n)
        app_state = STATE_UPLOAD;
    else
        app_state = STATE_SLEEP;
}

// ==================== 报警确认 ====================
static void do_alarm(void)
{
    uint8_t i;
    uint8_t still_abnormal = 1;
    SensorRecord_t record;
    ThresholdResult_t result;
    const char *alarm_type = "unknown";

    printf_debug("[SM] ALARM: rechecking %d times...\r\n", APP_ALARM_RECHECK_COUNT);

    for(i = 0; i < APP_ALARM_RECHECK_COUNT; i++)
    {
        trea_delay_ms(APP_ALARM_RECHECK_DELAY_MS);

        PT304D_Collect(&pt304d);
        pressure1 = pt304d.pressure;
        temperature1 = pt304d.temperature;
        voltage1 = adc_bat_read_voltage();

        result = threshold_check(pressure1, voltage1, last_pressure);
        printf_debug("[SM] ALARM recheck %d/%d: P=%.2f V=%.2f result=%d\r\n",
                     i + 1, APP_ALARM_RECHECK_COUNT, pressure1, voltage1, result);

        if(result == THRESHOLD_OK)
        {
            // 恢复正常: 偶发抖动
            printf_debug("[SM] ALARM: recovered at recheck %d, false alarm\r\n", i + 1);
            still_abnormal = 0;
            break;
        }
    }

    // 构造记录
    record.pressure = pressure1;
    record.temperature = temperature1;
    record.voltage = voltage1;
    rtc_get_time_str(record.timestamp, sizeof(record.timestamp));
    memset(record.reserved, 0, sizeof(record.reserved));

    if(still_abnormal)
    {
        // 确认报警
        record.flags = SENSOR_FLAG_ALARM;

        // 判断报警类型
        if(pressure1 < g_threshold.pressure_min)
            alarm_type = "pressure_low";
        else if(pressure1 > g_threshold.pressure_max)
            alarm_type = "pressure_high";
        else if(voltage1 < g_threshold.voltage_min)
            alarm_type = "voltage_low";
        else if(voltage1 > g_threshold.voltage_max)
            alarm_type = "voltage_high";
        else
            alarm_type = "pressure_mutation";

        printf_debug("[SM] *** ALARM CONFIRMED: %s ***\r\n", alarm_type);

        // Debug串口打印报警
        printf_debug("[SM] ALARM: P=%.2f T=%.2f V=%.2f @%s\r\n",
                     pressure1, temperature1, voltage1, record.timestamp);

        // 立即4G上报报警
        com_lpuart_init();
        trea_delay_ms(100);
        if(EC801E_EnsureConnected() == EC_OK)
        {
            EC801E_PublishAlarm(alarm_type, pressure1, voltage1);
        }
        trea_delay_ms(500);
        EC801E_SetPSM(1);
    }
    else
    {
        // 偶发抖动, 正常记录
        record.flags = 0;
    }

    // 存入缓冲区
    sensor_buf_push(&record);
    last_pressure = pressure1;
    wakeup_count++;

    // 回到休眠 (不在此处触发上报周期判断, 下次正常采集时再判断)
    app_state = STATE_SLEEP;
}

// ==================== 数据上报 (批量逐条) ====================
static void do_upload(void)
{
    uint16_t n, i;
    const SensorRecord_t *rec;

    printf_debug("[SM] UPLOAD: %d records\r\n", sensor_buf_count());
    com_lpuart_init();
    trea_delay_ms(100);

    // 确保MQTT连接 (断线自动重连)
    if(EC801E_EnsureConnected() != EC_OK)
    {
        printf_debug("[SM] UPLOAD: connect failed, skip\r\n");
        trea_delay_ms(500);
        EC801E_SetPSM(1);
        app_state = STATE_SLEEP;
        return;
    }

    // 逐条上传
    n = sensor_buf_count();
    for(i = 0; i < n; i++)
    {
        rec = sensor_buf_get(i);
        if(rec)
        {
            EC801E_PublishSingleRecord(rec);
            if(i < n - 1)
                trea_delay_ms(1000);   // 每条间隔1秒
        }
    }

    // 上传完成, 清空缓冲区
    sensor_buf_clear();
    wakeup_count = 0;

    printf_debug("[SM] UPLOAD done, buffer cleared\r\n");

    // 重新启用模块休眠
    trea_delay_ms(500);
    EC801E_SetPSM(1);

    app_state = STATE_SLEEP;
}

// ==================== 内部: JSON字段提取 ====================
static void extract_json_field(const char *buf, const char *field, char *out, uint16_t out_size)
{
    char *p;
    char *q;
    char *r;
    uint16_t len;

    out[0] = '\0';
    p = strstr(buf, field);
    if(!p) return;
    q = strchr(p + strlen(field), '"');
    if(!q) return;
    q++;  // skip opening quote
    r = strchr(q, '"');
    if(!r) return;
    len = (uint16_t)(r - q);
    if(len >= out_size) len = out_size - 1;
    memcpy(out, q, len);
    out[len] = '\0';
}

// ==================== 处理MQTT下发指令 (★最高优先级) ====================
static void do_downlink(void)
{
    static char dl_buf[256];
    char id_val[32] = {0};
    char cmd_val[64] = {0};

    printf_debug("[SM] DOWNLINK\r\n");
    com_lpuart_init();
    trea_delay_ms(100);

    if(EC801E_ReadDownlink(dl_buf, sizeof(dl_buf)) != EC_OK)
    {
        // 无下发消息, 可能是+QMTSTAT断线通知触发的唤醒
        printf_debug("[SM] No downlink, check MQTT...\r\n");
        if(EC801E_EnsureConnected() == EC_OK)
            printf_debug("[SM] MQTT OK\r\n");
        trea_delay_ms(500);
        EC801E_SetPSM(1);
        app_state = STATE_SLEEP;
        return;
    }

    // 解析FastBee JSON: [{"id":"xxx","value":"xxx"}]
    extract_json_field(dl_buf, "\"id\"", id_val, sizeof(id_val));
    extract_json_field(dl_buf, "\"value\"", cmd_val, sizeof(cmd_val));
    printf_debug("[SM] CMD id=%s value=%s\r\n", id_val, cmd_val);

    // ====== 指令分发 ======

    if(strcmp(id_val, "valve") == 0)
    {
        // ---- 阀门控制 (执行后立即上报结果) ----
        const char *result = "unknown";
        uint32_t t;
        gpio_bit_set(GPIOC, GPIO_PIN_0);
        pwm_init(160000, 0.5f, 0.5f);

        if(strcmp(cmd_val, "open") == 0 || strcmp(cmd_val, "1") == 0)
        {
            printf_debug("[SM] Valve OPEN\r\n");
            pwm_set_duty(0, 0.8f);
            pwm_set_duty(1, 0.0f);
            t = trea_millis();
            while(!motor_limit1_reached() && (trea_millis() - t) < 10000);
            pwm_set_duty(0, 0.0f);
            result = motor_limit1_reached() ? "open_ok" : "open_timeout";
        }
        else if(strcmp(cmd_val, "close") == 0 || strcmp(cmd_val, "0") == 0)
        {
            printf_debug("[SM] Valve CLOSE\r\n");
            pwm_set_duty(0, 0.0f);
            pwm_set_duty(1, 0.8f);
            t = trea_millis();
            while(!motor_limit2_reached() && (trea_millis() - t) < 10000);
            pwm_set_duty(1, 0.0f);
            result = motor_limit2_reached() ? "close_ok" : "close_timeout";
        }
        gpio_bit_reset(GPIOC, GPIO_PIN_0);
        printf_debug("[SM] Valve result: %s\r\n", result);

        // 立即上报结果
        EC801E_PublishResponse("valve", result);
    }
    else if(strcmp(id_val, "sensor_read") == 0)
    {
        // ---- 立即采集并上报当前值 ----
        PT304D_Collect(&pt304d);
        pressure1 = pt304d.pressure;
        temperature1 = pt304d.temperature;
        voltage1 = adc_bat_read_voltage();
        printf_debug("[SM] sensor_read: P=%.2f T=%.2f V=%.2f\r\n",
                     pressure1, temperature1, voltage1);

        // 确保MQTT连接活跃后再发布
        if(EC801E_EnsureConnected() == EC_OK)
        {
            EC801E_PublishSensorData(&pt304d);
            printf_debug("[SM] sensor_read: published OK\r\n");
        }
        else
        {
            printf_debug("[SM] sensor_read: MQTT connect failed\r\n");
        }
    }
    else if(strcmp(id_val, "collect_interval") == 0)
    {
        // ---- 修改采集周期 ----
        float val = (float)atof(cmd_val);
        if(val > 0)
        {
            g_interval.collect_interval_hours = val;
            config_save_interval();
            config_recalc_interval();
            printf_debug("[SM] collect_interval -> %.2fh (%dmin)\r\n",
                         val, g_interval.collect_interval_min);
        }
    }
    else if(strcmp(id_val, "upload_interval") == 0)
    {
        // ---- 修改上报周期 ----
        float val = (float)atof(cmd_val);
        if(val > 0)
        {
            g_interval.upload_interval_hours = val;
            config_save_interval();
            config_recalc_interval();
            printf_debug("[SM] upload_interval -> %.2fh (%dmin)\r\n",
                         val, g_interval.upload_interval_min);
        }
    }
    else if(strcmp(id_val, "keepalive") == 0)
    {
        // ---- 修改MQTT心跳 ----
        uint16_t ka = (uint16_t)atoi(cmd_val);
        if(ka >= 30)
        {
            static char cmd[64];
            g_threshold.keepalive_sec = ka;
            threshold_save();
            snprintf(cmd, sizeof(cmd), "AT+QMTCFG=\"keepalive\",0,%d\r\n", ka);
            EC801E_Wakeup();
            printf_cat1("%s", cmd);
            trea_delay_ms(500);
            printf_debug("[SM] keepalive -> %d s\r\n", ka);
        }
    }
    else if(strcmp(id_val, "threshold") == 0)
    {
        // ---- 修改阈值 ----
        if(threshold_parse(cmd_val))
            printf_debug("[SM] threshold updated\r\n");
    }
    else
    {
        printf_debug("[SM] Unknown cmd: %s\r\n", id_val);
    }

    // 重新启用模块休眠
    trea_delay_ms(500);
    EC801E_SetPSM(1);

    app_state = STATE_SLEEP;
}

// ==================== 主函数 ====================
int main(void)
{
    SensorRecord_t init_record;

    // ==================== STATE_INIT ====================
    sys_init();
    com_lpuart_init();
    lpuart_wakeup_init();

    config_load_all();
    config_enter_setup_mode(APP_SETUP_TIMEOUT_S);
    config_print_current();

    rtc_init_all();
    rtc_alarm_wakeup_init();
    PT304D_Init();
    sensor_buf_init();

    printf_debug("\r\n========================================\r\n");
    printf_debug("  Household Valve Controller v2.0\r\n");
    printf_debug("  Collect: %dmin  Upload: %dmin  Every %d wakeups\r\n",
                 g_interval.collect_interval_min,
                 g_interval.upload_interval_min,
                 g_interval.upload_every_n);
    printf_debug("  Threshold: P[%.1f,%.1f] V[%.1f,%.1f] mut=%.2f\r\n",
                 g_threshold.pressure_min, g_threshold.pressure_max,
                 g_threshold.voltage_min, g_threshold.voltage_max,
                 g_threshold.mutation_delta);
    printf_debug("  Keepalive: %d s\r\n", threshold_get_keepalive());
    printf_debug("========================================\r\n");

    // 4G开机 + 注网 + MQTT连接 + keepalive + 时间同步 + QSCLK
    EC801E_PowerOn();
    EC801E_InitAndConnect();

    // 首次采集+存入缓冲+上报
    PT304D_Collect(&pt304d);
    trea_delay_ms(500);
    pressure1 = pt304d.pressure;
    temperature1 = pt304d.temperature;
    voltage1 = adc_bat_read_voltage();

    init_record.pressure = pressure1;
    init_record.temperature = temperature1;
    init_record.voltage = voltage1;
    rtc_get_time_str(init_record.timestamp, sizeof(init_record.timestamp));
    init_record.flags = 0;
    memset(init_record.reserved, 0, sizeof(init_record.reserved));
    sensor_buf_push(&init_record);
    last_pressure = pressure1;

    printf_debug("[SM] INIT V=%.2f P=%.2f T=%.2f\r\n", voltage1, pressure1, temperature1);

    EC801E_PublishSensorData(&pt304d);
    trea_delay_ms(500);
    EC801E_SetPSM(1);
    wakeup_count = 0;

    // 初始化完成，进入休眠
    app_state = STATE_SLEEP;

    // ==================== 状态机主循环 ====================
    while(1)
    {
        switch(app_state)
        {
            case STATE_SLEEP:    do_sleep();    break;
            case STATE_WAKEUP:   do_wakeup();   break;
            case STATE_COLLECT:  do_collect();  break;
            case STATE_UPLOAD:   do_upload();   break;
            case STATE_DOWNLINK: do_downlink(); break;
            case STATE_ALARM:    do_alarm();    break;
            default:             app_state = STATE_SLEEP; break;
        }
    }
}





