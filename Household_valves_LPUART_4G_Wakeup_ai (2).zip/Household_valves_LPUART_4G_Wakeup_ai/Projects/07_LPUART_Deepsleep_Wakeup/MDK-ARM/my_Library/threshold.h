#ifndef THRESHOLD_H
#define THRESHOLD_H

#include <stdint.h>

/**
 * @file threshold.h
 * @brief 阈值检查模块 — 压力/电压上下限 + 突变检测
 *
 * 配置存储在EEPROM, 运行时使用全局变量 g_threshold
 */

// 阈值检查结果
typedef enum {
    THRESHOLD_OK = 0,           // 正常
    THRESHOLD_OVER_LIMIT,       // 超出上下限
    THRESHOLD_MUTATION          // 突变 (与上次差值过大)
} ThresholdResult_t;

// 阈值配置结构体
typedef struct {
    float pressure_min;         // 压力下限 (kPa)
    float pressure_max;         // 压力上限 (kPa)
    float voltage_min;          // 电压下限 (V)
    float voltage_max;          // 电压上限 (V)
    float mutation_delta;       // 突变阈值 (kPa)
    uint16_t keepalive_sec;     // MQTT心跳 (秒)
} ThresholdConfig_t;

// 全局阈值配置 (从EEPROM加载或使用默认值)
extern ThresholdConfig_t g_threshold;

// ==================== 接口函数 ====================

// 阈值检查: 检查当前值是否超限或突变
// last_pressure: 上次采集的压力值 (用于突变检测, 首次传-1忽略)
ThresholdResult_t threshold_check(float pressure, float voltage, float last_pressure);

// 从EEPROM加载阈值配置
void threshold_load(void);

// 保存阈值配置到EEPROM
void threshold_save(void);

// 解析阈值配置字符串: "pmin:0.5,pmax:35,vmin:3.0,vmax:4.2,mutation:0.5"
// 返回: 1=有效, 0=无效
int threshold_parse(const char *str);

// 获取当前keepalive值 (秒)
uint16_t threshold_get_keepalive(void);

#endif /* THRESHOLD_H */
