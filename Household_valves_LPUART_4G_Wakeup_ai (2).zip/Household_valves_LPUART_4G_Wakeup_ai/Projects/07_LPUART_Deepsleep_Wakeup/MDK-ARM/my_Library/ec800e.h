#ifndef EC801E_H
#define EC801E_H

#include <stdio.h>
#include <stdint.h>
#include "gd32l23x.h"
#include "PT_304_35.h"
#include "sensor_buffer.h"

// ==================== 状态码 ====================
typedef enum {
    EC_OK = 0,
    EC_ERROR,
    EC_TIMEOUT
} EC_Status_t;

// ==================== 硬件引脚 ====================
#define EC_PWRKEY_PORT       GPIOD
#define EC_PWRKEY_PIN        GPIO_PIN_9

// ==================== 接口函数 ====================

void EC801E_PowerOn(void);
void EC801E_PowerOff(void);

EC_Status_t EC801E_InitNetwork(void);
EC_Status_t EC801E_ConnectMQTT(void);
EC_Status_t EC801E_DisconnectMQTT(void);
EC_Status_t EC801E_PublishSensorData(PT304D_Data *data);
EC_Status_t EC801E_FullUpload(PT304D_Data *data);
void EC801E_SetPSM(uint8_t enable);

// 从4G模块获取网络时间 (AT+CCLK?)
// 成功后自动调用 rtc_set_from_cclk() 设置RTC
// 返回: EC_OK=成功, EC_ERROR=失败
EC_Status_t EC801E_SyncTime(void);

// ==================== 持久连接 + 下发 ====================

// 首次初始化: 网络+MQTT连接+订阅+QSCLK (上电调用一次)
EC_Status_t EC801E_InitAndConnect(void);

// 订阅下发topic (从topic_up推导: /post → /get)
EC_Status_t EC801E_SubscribeTopic(void);

// 确保MQTT已连接 (断线自动重连)
EC_Status_t EC801E_EnsureConnected(void);

// 读取MQTT下发消息 (LPUART唤醒后调用)
// payload_buf: 输出JSON payload, buf_size: 缓冲区大小
// 返回: EC_OK=收到下发, EC_TIMEOUT=无数据
EC_Status_t EC801E_ReadDownlink(char *payload_buf, uint16_t buf_size);

// 唤醒模块 (QSCLK模式下首字节可能丢失,先发AT)
void EC801E_Wakeup(void);

// 发布单条历史记录 (用于批量上报)
EC_Status_t EC801E_PublishSingleRecord(const SensorRecord_t *record);

// 发布报警消息 (确认异常后立即调用)
EC_Status_t EC801E_PublishAlarm(const char *alarm_type, float pressure, float voltage);

// 发布下发响应结果
EC_Status_t EC801E_PublishResponse(const char *id, const char *value);

#endif
