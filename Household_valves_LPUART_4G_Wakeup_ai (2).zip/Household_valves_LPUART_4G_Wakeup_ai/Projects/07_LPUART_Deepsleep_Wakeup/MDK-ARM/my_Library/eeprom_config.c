/**
 * @file eeprom_config.c
 * @brief AT24C16 EEPROM 配置存储 + Debug串口配置命令解析
 *
 * 支持的Debug串口命令:
 *   间隔配置: {collect:0.5,upload:1.0}
 *   MQTT配置: {clientId:xxx,username:xxx,passwd:xxx,port:1883}
 */

#include "eeprom_config.h"
#include "AT24c16.h"
#include "usart.h"
#include "delay.h"
#include "app_config.h"
#include "threshold.h"
#include <string.h>
#include <stdlib.h>
#include <stdio.h>

// ==================== 全局运行时配置 ====================
AppInterval_t g_interval;
MqttConfig_t  g_mqtt;

// ==================== 内部工具 ====================

// 从EEPROM读float
static float ee_read_float(uint16_t addr)
{
    float val = 0;
    AT24C16_Read(addr, (uint8_t *)&val, sizeof(float));
    return val;
}

// 写float到EEPROM
static void ee_write_float(uint16_t addr, float val)
{
    AT24C16_Write(addr, (const uint8_t *)&val, sizeof(float));
}

// 从EEPROM读字符串
static void ee_read_string(uint16_t addr, char *buf, uint16_t max_len)
{
    AT24C16_Read(addr, (uint8_t *)buf, max_len);
    buf[max_len - 1] = '\0';  // 确保终止
}

// 写字符串到EEPROM（含终止符）
static void ee_write_string(uint16_t addr, const char *str, uint16_t max_len)
{
    uint16_t len = (uint16_t)strlen(str) + 1;
    if(len > max_len) len = max_len;
    AT24C16_Write(addr, (const uint8_t *)str, len);
}

// 从字符串中提取key:value对的value
// 输入: src = "clientId:abc,username:def", key = "clientId"
// 输出: out = "abc", 返回1成功
static int extract_field(const char *src, const char *key, char *out, uint16_t out_size)
{
    char search_key[32];
    snprintf(search_key, sizeof(search_key), "%s:", key);

    const char *p = strstr(src, search_key);
    if(!p) return 0;

    p += strlen(search_key);
    uint16_t i = 0;
    while(*p && *p != ',' && *p != '}' && i < out_size - 1)
    {
        out[i++] = *p++;
    }
    out[i] = '\0';
    return (i > 0) ? 1 : 0;
}

// ==================== 重新计算间隔 ====================
void config_recalc_interval(void)
{
    if(g_interval.collect_interval_hours < 0.01f)
        g_interval.collect_interval_hours = 0.01f;
    if(g_interval.upload_interval_hours < g_interval.collect_interval_hours)
        g_interval.upload_interval_hours = g_interval.collect_interval_hours;

    g_interval.collect_interval_min = (uint16_t)(g_interval.collect_interval_hours * 60.0f);
    g_interval.upload_interval_min  = (uint16_t)(g_interval.upload_interval_hours * 60.0f);

    if(g_interval.collect_interval_min < 1)
        g_interval.collect_interval_min = 1;
    if(g_interval.upload_interval_min < g_interval.collect_interval_min)
        g_interval.upload_interval_min = g_interval.collect_interval_min;

    g_interval.upload_every_n = g_interval.upload_interval_min / g_interval.collect_interval_min;
    if(g_interval.upload_every_n < 1)
        g_interval.upload_every_n = 1;
}

// ==================== 从EEPROM加载全部配置 ====================
void config_load_all(void)
{
    uint8_t magic = 0;

    // --- 加载间隔配置 ---
    AT24C16_Read(EE_ADDR_INTERVAL_MAGIC, &magic, 1);
    if(magic == EE_MAGIC_INTERVAL)
    {
        g_interval.collect_interval_hours = ee_read_float(EE_ADDR_COLLECT_HOURS);
        g_interval.upload_interval_hours  = ee_read_float(EE_ADDR_UPLOAD_HOURS);
        printf_debug("[CFG] EEPROM interval loaded: collect=%.2fh upload=%.2fh\r\n",
                     g_interval.collect_interval_hours, g_interval.upload_interval_hours);
    }
    else
    {
        // 使用编译时默认值
        g_interval.collect_interval_hours = APP_DEFAULT_COLLECT_HOURS;
        g_interval.upload_interval_hours  = APP_DEFAULT_UPLOAD_HOURS;
        printf_debug("[CFG] No interval in EEPROM, using defaults\r\n");
    }
    config_recalc_interval();

    // --- 加载MQTT配置 ---
    AT24C16_Read(EE_ADDR_MQTT_MAGIC, &magic, 1);
    if(magic == EE_MAGIC_MQTT)
    {
        ee_read_string(EE_ADDR_MQTT_CLIENT_ID, g_mqtt.client_id, MQTT_FIELD_MAX);
        ee_read_string(EE_ADDR_MQTT_USERNAME,  g_mqtt.username,  MQTT_FIELD_MAX);
        ee_read_string(EE_ADDR_MQTT_PASSWORD,  g_mqtt.password,  MQTT_FIELD_MAX);
        ee_read_string(EE_ADDR_MQTT_SERVER,    g_mqtt.server,    MQTT_FIELD_MAX);
        ee_read_string(EE_ADDR_MQTT_TOPIC_UP,  g_mqtt.topic_up,  MQTT_TOPIC_MAX);
        AT24C16_Read(EE_ADDR_MQTT_PORT, (uint8_t *)&g_mqtt.port, 2);
        printf_debug("[CFG] EEPROM MQTT loaded: %s@%s:%d\r\n",
                     g_mqtt.client_id, g_mqtt.server, g_mqtt.port);
    }
    else
    {
        // 使用编译时默认值
        strncpy(g_mqtt.client_id, APP_DEFAULT_MQTT_CLIENT_ID, MQTT_FIELD_MAX - 1);
        strncpy(g_mqtt.username,  APP_DEFAULT_MQTT_USER,      MQTT_FIELD_MAX - 1);
        strncpy(g_mqtt.password,  APP_DEFAULT_MQTT_PASS,      MQTT_FIELD_MAX - 1);
        strncpy(g_mqtt.server,    APP_DEFAULT_MQTT_SERVER,    MQTT_FIELD_MAX - 1);
        strncpy(g_mqtt.topic_up,  APP_DEFAULT_MQTT_TOPIC,     MQTT_TOPIC_MAX - 1);
        g_mqtt.port = APP_DEFAULT_MQTT_PORT;
        printf_debug("[CFG] No MQTT in EEPROM, using defaults\r\n");
    }

    // --- 加载阈值+心跳配置 ---
    threshold_load();
}

// ==================== 保存间隔配置到EEPROM ====================
void config_save_interval(void)
{
    uint8_t magic = EE_MAGIC_INTERVAL;
    AT24C16_WriteByte(EE_ADDR_INTERVAL_MAGIC, magic);
    ee_write_float(EE_ADDR_COLLECT_HOURS, g_interval.collect_interval_hours);
    ee_write_float(EE_ADDR_UPLOAD_HOURS,  g_interval.upload_interval_hours);
    config_recalc_interval();
    printf_debug("[CFG] Interval saved: collect=%.2fh upload=%.2fh\r\n",
                 g_interval.collect_interval_hours, g_interval.upload_interval_hours);
}

// ==================== 保存MQTT配置到EEPROM ====================
void config_save_mqtt(void)
{
    uint8_t magic = EE_MAGIC_MQTT;
    AT24C16_WriteByte(EE_ADDR_MQTT_MAGIC, magic);
    ee_write_string(EE_ADDR_MQTT_CLIENT_ID, g_mqtt.client_id, MQTT_FIELD_MAX);
    ee_write_string(EE_ADDR_MQTT_USERNAME,  g_mqtt.username,  MQTT_FIELD_MAX);
    ee_write_string(EE_ADDR_MQTT_PASSWORD,  g_mqtt.password,  MQTT_FIELD_MAX);
    ee_write_string(EE_ADDR_MQTT_SERVER,    g_mqtt.server,    MQTT_FIELD_MAX);
    ee_write_string(EE_ADDR_MQTT_TOPIC_UP,  g_mqtt.topic_up,  MQTT_TOPIC_MAX);
    AT24C16_Write(EE_ADDR_MQTT_PORT, (const uint8_t *)&g_mqtt.port, 2);
    printf_debug("[CFG] MQTT saved: %s@%s:%d\r\n",
                 g_mqtt.client_id, g_mqtt.server, g_mqtt.port);
}

// ==================== 内部: 从串口读一行 ====================
// 阻塞读一行（带超时），返回长度，0=超时无数据
static uint16_t read_debug_line(char *buf, uint16_t buf_size, uint32_t timeout_ms)
{
    uint16_t idx = 0;
    uint32_t start = trea_millis();
    uint8_t ch;

    while((trea_millis() - start) < timeout_ms)
    {
        if(trea_uart_recv_byte_timeout(USART0, &ch, 50))
        {
            if(ch == '\r' || ch == '\n')
            {
                if(idx > 0) { buf[idx] = '\0'; return idx; }
                continue;
            }
            if(idx < buf_size - 1)
                buf[idx++] = (char)ch;
        }
    }
    buf[idx] = '\0';
    return idx;
}

// ==================== 解析间隔命令 ====================
// 格式: {collect:0.5,upload:1.0}
// 返回: 1=有效, 0=无效
static int parse_interval_line(const char *cmd)
{
    if(!strstr(cmd, "collect:") || !strstr(cmd, "upload:")) return 0;

    char val_buf[16];
    if(extract_field(cmd, "collect", val_buf, sizeof(val_buf)))
        g_interval.collect_interval_hours = (float)atof(val_buf);
    if(extract_field(cmd, "upload", val_buf, sizeof(val_buf)))
        g_interval.upload_interval_hours = (float)atof(val_buf);

    config_save_interval();
    return 1;
}

// ==================== 解析MQTT命令 ====================
// 格式: {clientId:xxx,username:xxx,passwd:xxx,port:1883}
// 返回: 1=有效, 0=无效
static int parse_mqtt_line(const char *cmd)
{
    if(!strstr(cmd, "clientId:")) return 0;

    char val_buf[MQTT_FIELD_MAX];

    if(extract_field(cmd, "clientId", val_buf, sizeof(val_buf)))
        strncpy(g_mqtt.client_id, val_buf, MQTT_FIELD_MAX - 1);
    if(extract_field(cmd, "username", val_buf, sizeof(val_buf)))
        strncpy(g_mqtt.username, val_buf, MQTT_FIELD_MAX - 1);
    if(extract_field(cmd, "passwd", val_buf, sizeof(val_buf)))
        strncpy(g_mqtt.password, val_buf, MQTT_FIELD_MAX - 1);
    if(extract_field(cmd, "port", val_buf, sizeof(val_buf)))
        g_mqtt.port = (uint16_t)atoi(val_buf);
    if(extract_field(cmd, "server", val_buf, sizeof(val_buf)))
        strncpy(g_mqtt.server, val_buf, MQTT_FIELD_MAX - 1);
    if(extract_field(cmd, "topic", val_buf, sizeof(val_buf)))
        strncpy(g_mqtt.topic_up, val_buf, MQTT_TOPIC_MAX - 1);

    config_save_mqtt();
    return 1;
}

// ==================== 兼容旧接口 ====================
int config_parse_debug_cmd(void)
{
    static char cmd_buf[512];
    uint16_t len = read_debug_line(cmd_buf, sizeof(cmd_buf), 100);
    if(len == 0) return 0;
    if(parse_interval_line(cmd_buf)) return 1;
    if(parse_mqtt_line(cmd_buf)) return 1;
    if(threshold_parse(cmd_buf)) return 1;
    printf_debug("[CFG] Unknown cmd: %s\r\n", cmd_buf);
    return 0;
}

// ==================== 启动配置模式 ====================
void config_enter_setup_mode(uint16_t timeout_s)
{
    static char line_buf[512];
    uint8_t need_reconfig = 0;

    // ===== 3秒窗口：检测 "reset" 指令 =====
    printf_debug("\r\n[CFG] Send 'reset' within 3s to reconfigure...\r\n");
    uint32_t start = trea_millis();
    while((trea_millis() - start) < 3000)
    {
        uint16_t len = read_debug_line(line_buf, sizeof(line_buf), 200);
        if(len > 0 && strstr(line_buf, "reset"))
        {
            printf_debug("[CFG] Reset received, entering config mode\r\n");
            need_reconfig = 1;
            break;
        }
    }

    // 未收到reset：两个magic都有效则直接运行
    if(!need_reconfig)
    {
        uint8_t m1 = 0, m2 = 0;
        AT24C16_Read(EE_ADDR_INTERVAL_MAGIC, &m1, 1);
        AT24C16_Read(EE_ADDR_MQTT_MAGIC, &m2, 1);
        if(m1 == EE_MAGIC_INTERVAL && m2 == EE_MAGIC_MQTT)
        {
            printf_debug("[CFG] Config valid, continue\r\n");
            return;
        }
        printf_debug("[CFG] EEPROM not configured, entering setup\r\n");
    }

    // ===== 阶段1: 时间周期配置 =====
    {
        uint8_t magic = 0;
        AT24C16_Read(EE_ADDR_INTERVAL_MAGIC, &magic, 1);
        if(!need_reconfig && magic == EE_MAGIC_INTERVAL)
        {
            printf_debug("[CFG] Interval valid, skip\r\n");
        }
        else
        {
            printf_debug("\r\n[CFG] === Stage 1: Interval ===\r\n");
            printf_debug("  Send: {collect:0.5,upload:1.0}\r\n");
            printf_debug("  Waiting...\r\n");

            while(1)
            {
                uint16_t len = read_debug_line(line_buf, sizeof(line_buf), 6000);
                if(len == 0)
                {
                    printf_debug("[CFG] Interval: still waiting...\r\n");
                    continue;
                }
                if(parse_interval_line(line_buf))
                {
                    printf_debug("[CFG] Interval saved OK\r\n");
                    config_print_current();
                    break;
                }
                printf_debug("[CFG] Invalid, need: {collect:X,upload:X}\r\n");
            }
        }
    }

    // ===== 阶段2: MQTT参数配置 =====
    {
        uint8_t magic = 0;
        AT24C16_Read(EE_ADDR_MQTT_MAGIC, &magic, 1);
        if(!need_reconfig && magic == EE_MAGIC_MQTT)
        {
            printf_debug("[CFG] MQTT valid, skip\r\n");
        }
        else
        {
            printf_debug("\r\n[CFG] === Stage 2: MQTT ===\r\n");
            printf_debug("  Send: {clientId:xxx,username:xxx,passwd:xxx,port:1883}\r\n");
            printf_debug("  Waiting...\r\n");

            while(1)
            {
                uint16_t len = read_debug_line(line_buf, sizeof(line_buf), 6000);
                if(len == 0)
                {
                    printf_debug("[CFG] MQTT: still waiting...\r\n");
                    continue;
                }
                if(parse_mqtt_line(line_buf))
                {
                    printf_debug("[CFG] MQTT saved OK\r\n");
                    config_print_current();
                    break;
                }
                printf_debug("[CFG] Invalid, need: {clientId:xxx,...}\r\n");
            }
        }
    }

    printf_debug("[CFG] Setup done\r\n");
}

// ==================== 打印当前配置 ====================
void config_print_current(void)
{
    printf_debug("\r\n--- Current Config ---\r\n");
    printf_debug("  Collect: %.2f h (%d min)\r\n",
                 g_interval.collect_interval_hours, g_interval.collect_interval_min);
    printf_debug("  Upload:  %.2f h (%d min)\r\n",
                 g_interval.upload_interval_hours, g_interval.upload_interval_min);
    printf_debug("  Upload every %d wakeups\r\n", g_interval.upload_every_n);
    printf_debug("  MQTT: %s@%s:%d\r\n",
                 g_mqtt.client_id, g_mqtt.server, g_mqtt.port);
    printf_debug("  User: %s  Topic: %s\r\n", g_mqtt.username, g_mqtt.topic_up);
    printf_debug("----------------------\r\n");
}

// ==================== 唤醒后检测reset指令 ====================
void config_check_reset(uint16_t timeout_ms)
{
    static char line_buf[64];
    uint32_t start = trea_millis();

    printf_debug("[CFG] reset? (%dms)\r\n", timeout_ms);

    while((trea_millis() - start) < (uint32_t)timeout_ms)
    {
        uint16_t len = read_debug_line(line_buf, sizeof(line_buf), 200);
        if(len > 0 && strstr(line_buf, "reset"))
        {
            printf_debug("[CFG] Reset received in wakeup!\r\n");
            config_load_all();
            config_enter_setup_mode(0);
            config_print_current();
            return;
        }
    }
}
