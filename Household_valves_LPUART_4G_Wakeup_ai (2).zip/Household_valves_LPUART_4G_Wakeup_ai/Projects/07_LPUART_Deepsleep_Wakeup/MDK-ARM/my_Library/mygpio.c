#include "mygpio.h"



void gpio_init(void)
{
		/* enable the LED GPIO clock */
    rcu_periph_clock_enable(RCU_GPIOD);
    /* configure LED GPIO pin */
    gpio_mode_set(GPIOD, GPIO_MODE_OUTPUT, GPIO_PUPD_NONE, GPIO_PIN_9 | GPIO_PIN_1 | GPIO_PIN_4);
    gpio_output_options_set(GPIOD, GPIO_OTYPE_PP, GPIO_OSPEED_2MHZ, GPIO_PIN_9 | GPIO_PIN_1 | GPIO_PIN_4);
    /* reset GPIO pin */
    gpio_bit_set(GPIOD, GPIO_PIN_9 | GPIO_PIN_1 | GPIO_PIN_4);
}
    
void motor_init(void)
{
    rcu_periph_clock_enable(RCU_GPIOC);

    /* PC0: 电机使能，推挽输出，默认低（关闭） */
    gpio_mode_set(GPIOC, GPIO_MODE_OUTPUT, GPIO_PUPD_NONE, GPIO_PIN_0);
    gpio_output_options_set(GPIOC, GPIO_OTYPE_PP, GPIO_OSPEED_2MHZ, GPIO_PIN_0);
    gpio_bit_reset(GPIOC, GPIO_PIN_0);

    /* PC1/PC2: 电机到位信号输入，内部上拉（低电平=到位） */
    gpio_mode_set(GPIOC, GPIO_MODE_INPUT, GPIO_PUPD_PULLUP, GPIO_PIN_1 | GPIO_PIN_2);
}

/* 读取到位信号: 返回1=到位(低电平), 0=未到位 */
uint8_t motor_limit1_reached(void)
{
    return (gpio_input_bit_get(GPIOC, GPIO_PIN_1) == RESET) ? 1 : 0;
}

uint8_t motor_limit2_reached(void)
{
    return (gpio_input_bit_get(GPIOC, GPIO_PIN_2) == RESET) ? 1 : 0;
}



/*
if(motor_limit1_reached()) {
    // 电机方向1已到位，停止
}
if(motor_limit2_reached()) {
    // 电机方向2已到位，停止
}
*/