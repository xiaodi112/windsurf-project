#ifndef APP_CONFIG_H
#define APP_CONFIG_H

#include <stdint.h>

/*
 * ============================================================
 *  编译时默认配置 — 当EEPROM无有效数据时使用
 *  运行时实际使用 g_interval / g_mqtt 全局变量（从EEPROM加载）
 *  用户可通过Debug串口在线修改并保存到EEPROM
 * ============================================================
 */

/* ---------- 间隔默认值（EEPROM无数据时使用，用户未配置则1分钟采集+上报） ---------- */
#define APP_DEFAULT_COLLECT_HOURS     (1.0f / 60.0f)
#define APP_DEFAULT_UPLOAD_HOURS      (1.0f / 60.0f)

/* ---------- MQTT默认值（EEPROM无数据时使用） ---------- */
#define APP_DEFAULT_MQTT_CLIENT_ID    "S&D54GRG29T5HB0&149&1"
#define APP_DEFAULT_MQTT_SERVER       "120.78.220.171"
#define APP_DEFAULT_MQTT_PORT         1883
#define APP_DEFAULT_MQTT_USER         "FastBee"
#define APP_DEFAULT_MQTT_PASS         "P41TQ4X1Y0C57IW0"
#define APP_DEFAULT_MQTT_TOPIC        "/149/D54GRG29T5HB0/property/post"

/* ---------- 固定参数（不通过串口修改） ---------- */
#define APP_EC_MAX_RETRY              5
#define APP_AT_TIMEOUT_SHORT          2000
#define APP_AT_TIMEOUT_LONG           10000
#define APP_AT_TIMEOUT_MQTT           15000
#define APP_MQTT_KEEPALIVE            300    /* MQTT心跳(秒), 模块自动发PINGREQ */

/* ---------- 阈值默认值（EEPROM无数据时使用） ---------- */
#define APP_DEFAULT_PRESSURE_MIN      -0.5f      /* 压力下限 (kPa) */
#define APP_DEFAULT_PRESSURE_MAX      35.0f     /* 压力上限 (kPa) */
#define APP_DEFAULT_VOLTAGE_MIN       3.0f      /* 电压下限 (V) */
#define APP_DEFAULT_VOLTAGE_MAX       4.2f      /* 电压上限 (V) */
#define APP_DEFAULT_MUTATION_DELTA    2.0f      /* 压力突变阈值 (kPa) */

/* ---------- 报警确认参数 ---------- */
#define APP_ALARM_RECHECK_COUNT       5         /* 异常重采次数 */
#define APP_ALARM_RECHECK_DELAY_MS    500       /* 重采间隔 (ms) */

/* ---------- 启动配置等待时间（秒） ---------- */
#define APP_SETUP_TIMEOUT_S           2

#endif /* APP_CONFIG_H */
