#ifndef EEPROM_CONFIG_H
#define EEPROM_CONFIG_H

#include <stdint.h>

/*
 * ============================================================
 *  AT24C16 EEPROM 配置存储
 * ============================================================
 *
 *  存储布局 (AT24C16: 2048字节):
 *  ┌─────────────────────────────────────────┐
 *  │ 0x000: 间隔配置 Magic (0xA5 = 有效)     │
 *  │ 0x001-0x004: 采集周期 (float, 小时)      │
 *  │ 0x005-0x008: 上报周期 (float, 小时)      │
 *  ├─────────────────────────────────────────┤
 *  │ 0x020: MQTT配置 Magic (0x5A = 有效)      │
 *  │ 0x021-0x060: ClientID (64字节)           │
 *  │ 0x061-0x0A0: Username (64字节)           │
 *  │ 0x0A1-0x0E0: Password (64字节)           │
 *  │ 0x0E1-0x0E2: Port (uint16_t)            │
 *  │ 0x0E3-0x122: Server IP (64字节)          │
 *  │ 0x123-0x1A2: Topic上报 (128字节)         │
 *  └─────────────────────────────────────────┘
 */

// EEPROM地址定义
#define EE_ADDR_INTERVAL_MAGIC    0x000
#define EE_ADDR_COLLECT_HOURS     0x001   // float, 4 bytes
#define EE_ADDR_UPLOAD_HOURS      0x005   // float, 4 bytes

#define EE_ADDR_MQTT_MAGIC        0x020
#define EE_ADDR_MQTT_CLIENT_ID    0x021   // 64 bytes
#define EE_ADDR_MQTT_USERNAME     0x061   // 64 bytes
#define EE_ADDR_MQTT_PASSWORD     0x0A1   // 64 bytes
#define EE_ADDR_MQTT_PORT         0x0E1   // 2 bytes
#define EE_ADDR_MQTT_SERVER       0x0E3   // 64 bytes
#define EE_ADDR_MQTT_TOPIC_UP     0x123   // 128 bytes

#define EE_MAGIC_INTERVAL         0xA5
#define EE_MAGIC_MQTT             0x5A

// 字段最大长度
#define MQTT_FIELD_MAX            64
#define MQTT_TOPIC_MAX            128

// ==================== 运行时配置结构体 ====================

typedef struct {
    float collect_interval_hours;   // 采集周期（小时）
    float upload_interval_hours;    // 上报周期（小时）
    uint16_t collect_interval_min;  // 自动计算: 分钟
    uint16_t upload_interval_min;   // 自动计算: 分钟
    uint16_t upload_every_n;        // 自动计算: 每N次唤醒上报
} AppInterval_t;

typedef struct {
    char client_id[MQTT_FIELD_MAX];
    char username[MQTT_FIELD_MAX];
    char password[MQTT_FIELD_MAX];
    char server[MQTT_FIELD_MAX];
    char topic_up[MQTT_TOPIC_MAX];
    uint16_t port;
} MqttConfig_t;

// 全局运行时配置（其他文件通过extern引用）
extern AppInterval_t g_interval;
extern MqttConfig_t  g_mqtt;

// ==================== 接口函数 ====================

// 从EEPROM加载配置（上电调用）
void config_load_all(void);

// 保存间隔配置到EEPROM
void config_save_interval(void);

// 保存MQTT配置到EEPROM
void config_save_mqtt(void);

// 解析debug串口命令（非阻塞，有数据才处理）
// 返回: 1=收到有效配置, 0=无数据/无效
int config_parse_debug_cmd(void);

// 启动时等待配置（阻塞timeout_s秒）
// 在timeout内可多次接收配置命令
void config_enter_setup_mode(uint16_t timeout_s);

// 打印当前配置到debug串口
void config_print_current(void);

// 重新计算间隔的分钟数和唤醒次数
void config_recalc_interval(void);

// 唤醒后短暂检测debug串口是否收到"reset"
// timeout_ms: 等待时间(毫秒)
// 返回: 1=收到reset并已重新配置, 0=无数据
void config_check_reset(uint16_t timeout_ms);

#endif /* EEPROM_CONFIG_H */
