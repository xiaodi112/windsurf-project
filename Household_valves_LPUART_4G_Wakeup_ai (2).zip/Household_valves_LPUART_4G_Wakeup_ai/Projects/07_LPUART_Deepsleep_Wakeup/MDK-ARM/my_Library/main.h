#ifndef MAIN_H
#define MAIN_H

#include "stdint.h"
#include "PT_304_35.h"

//#define  GD32_FLASH_SADDR   0x08000000
//#define  GD32_PAGE_SIZE     1024
//#define  GD32_PAGE_NUM      256
//#define  GD32_B_PAGE_NUM    50
//#define  GD32_A_PAGE_NUM    (GD32_PAGE_NUM - GD32_B_PAGE_NUM)
//#define  GD32_A_START_PAGE  GD32_B_PAGE_NUM
//#define  GD32_A_SADDR       (GD32_FLASH_SADDR + GD32_A_START_PAGE * GD32_PAGE_SIZE)
//#define VECT_TAB_OFFSET 	0x0000C800

//#define  UPDATA_A_FLAG      0x00000001
//#define  IAP_XMODEMC_FLAG   0x00000002
//#define  IAP_XMODEMD_FLAG   0x00000004
//#define  SET_VERSION_FLAG   0x00000008
//#define  CMD_5_FLAG         0x00000010
//#define  CMD5_XMODEM_FLAG   0x00000020
//#define  CMD_6_FLAG         0x00000040

//#define OTA_SET_FLAG        0xAABB1122

//typedef struct{
//	uint32_t OTA_flag;
//	uint32_t Firelen[11];
//	uint8_t  OTA_ver[32];
//}OTA_InfoCB;

//#define OTA_INFOCB_SIZE sizeof(OTA_InfoCB)

//typedef struct{
//	uint8_t  UpDataBuff[GD32_PAGE_SIZE];
//	uint32_t GD25Q16_BlockNB;
//	uint32_t XmodemTimer;
//	uint32_t XmodemNB;
//	uint32_t XmodemCRC;
//}UpDataA_CB;

//extern OTA_InfoCB OTA_Info;
//extern UpDataA_CB UpDataA;
//extern uint32_t BootStaFlag;
//extern PT304D_Data pt304d;
extern float voltage1;
extern float pressure1;
extern float temperature1;
#endif