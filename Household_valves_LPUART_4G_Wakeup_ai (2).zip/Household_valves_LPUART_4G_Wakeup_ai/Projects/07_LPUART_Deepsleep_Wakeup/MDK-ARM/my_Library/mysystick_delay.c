#include "mysystick_delay.h"
#include "gd32l23x_misc.h"
 
 
static float counts_1ms = 0;
static float counts_1us = 0;
 
 
 /*Systick---CLKSOURCE--ʱ��Դ*/
void my_systick_config(void)
{
	systick_clksource_set(SYSTICK_CLKSOURCE_HCLK_DIV8);//8��Ƶ
	counts_1ms = (float)SystemCoreClock/8000;
	counts_1us = counts_1ms/1000;
}

/*ms*/
void my_systick_delay_ms(uint32_t counts)
{
	uint32_t ctl;
	SysTick->LOAD = (uint32_t)(counts * counts_1ms);//�Զ���װ��
	SysTick->VAL = 0x0000U;//����������//VAL��ǰֵ
	SysTick->CTRL |= SysTick_CTRL_ENABLE_Msk;//ENABLE  (1UL /*<< SysTick_CTRL_ENABLE_Pos*/)=====SysTick_CTRL_ENABLE_Pos = 0
	
	do{
		ctl = SysTick->CTRL;//��¼
		
	}while((ctl & SysTick_CTRL_ENABLE_Msk) && !(SysTick->CTRL & SysTick_CTRL_COUNTFLAG_Msk));//��ɼ���
	
	SysTick->CTRL &= ~SysTick_CTRL_ENABLE_Msk;
	SysTick->VAL = 0x0000U;
}

/*us*/
void my_systick_delay_us(uint32_t counts)
{
	uint32_t ctl;
	SysTick->LOAD = (uint32_t)(counts * counts_1us);
	SysTick->VAL = 0x0000U;//����������//VAL��ǰֵ
	SysTick->CTRL |= SysTick_CTRL_ENABLE_Msk;//(1UL /*<< SysTick_CTRL_ENABLE_Pos*/)=====SysTick_CTRL_ENABLE_Pos = 0
	
	do{
		ctl = SysTick->CTRL;
		
	}while((ctl & SysTick_CTRL_ENABLE_Msk) && !(SysTick->CTRL & SysTick_CTRL_COUNTFLAG_Msk));
	
	SysTick->CTRL &= ~SysTick_CTRL_ENABLE_Msk;
	SysTick->VAL = 0x0000U;
}
 
 
 
 