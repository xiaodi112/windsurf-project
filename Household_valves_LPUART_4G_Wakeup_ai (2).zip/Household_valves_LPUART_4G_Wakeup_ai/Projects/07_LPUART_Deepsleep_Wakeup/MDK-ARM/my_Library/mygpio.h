﻿#ifndef MYGPIO__H
#define MYGPIO__H

#include "gd32l23x.h"

void gpio_init(void);
void motor_init(void);

uint8_t motor_limit1_reached(void);
uint8_t motor_limit2_reached(void);

#endif
