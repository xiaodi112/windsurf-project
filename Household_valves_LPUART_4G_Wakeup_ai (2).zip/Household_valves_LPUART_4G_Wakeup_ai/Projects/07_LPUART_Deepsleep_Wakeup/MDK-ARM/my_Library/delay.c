#include "delay.h"

#include "systick.h"
#include "gd32l23x.h"
#include "gd32l23x_rtc.h"
#include <stdio.h>
#include <stddef.h>

static volatile uint32_t s_ms = 0;

void trea_time_isr(void)
{
    s_ms++;
}

uint32_t trea_millis(void)
{
    return s_ms;
}

//void trea_delay_ms(uint32_t ms)
//{
//    delay_1ms(ms);
//}

//void delay_us(uint32_t us)
//{
//    uint32_t ticks;
//    uint32_t start, now;
//    uint32_t reload = SysTick->LOAD + 1;

//    /* 每微秒需要的tick数 */
//    ticks = us * (SystemCoreClock / 1000000U);

//    start = SysTick->VAL;

//    while(1) {
//        now = SysTick->VAL;

//        if(start >= now) {
//            if((start - now) >= ticks) {
//                break;
//            }
//        } else {
//            /* 处理计数器回绕 */
//            if((start + reload - now) >= ticks) {
//                break;
//            }
//        }
//    }
//}


static float counts_1ms = 0;
static float counts_1us = 0;
 
 
 /*Systick---CLKSOURCE--时钟源*/
void my_systick_config(void)
{
	systick_clksource_set(SYSTICK_CLKSOURCE_HCLK_DIV8);//8分频
	counts_1ms = (float)SystemCoreClock/8000;
	counts_1us = counts_1ms/1000;

	// 更新LOAD为HCLK/8下的1ms周期（systick_config设的是HCLK的LOAD，切8分频后周期变8ms）
	SysTick->CTRL &= ~SysTick_CTRL_ENABLE_Msk;
	SysTick->LOAD = (uint32_t)(SystemCoreClock / 8000U) - 1U;
	SysTick->VAL  = 0U;
	SysTick->CTRL |= SysTick_CTRL_ENABLE_Msk;
}

/*ms*/
void trea_delay_ms(uint32_t counts)
{
	if(counts == 0) return;
	uint32_t saved_load = SysTick->LOAD;
	uint32_t saved_ctrl = SysTick->CTRL;
	uint32_t ctl;

	// 关闭SysTick，切换为纯轮询（无ISR干扰）
	SysTick->CTRL = 0;
	SysTick->LOAD = (uint32_t)(counts * counts_1ms);
	SysTick->VAL  = 0x0000U;
	SysTick->CTRL = SysTick_CTRL_ENABLE_Msk; // ENABLE=1, TICKINT=0, CLKSOURCE=0(HCLK/8)

	do{
		ctl = SysTick->CTRL;
	}while((ctl & SysTick_CTRL_ENABLE_Msk) && !(ctl & SysTick_CTRL_COUNTFLAG_Msk));

	// 补偿延时期间未递增的s_ms
	s_ms += counts;

	// 恢复SysTick ISR配置
	SysTick->CTRL = 0;
	SysTick->LOAD = saved_load;
	SysTick->VAL  = 0x0000U;
	SysTick->CTRL = saved_ctrl;
}

/*us*/
void delay_us(uint32_t counts)
{
	if(counts == 0) return;
	uint32_t saved_load = SysTick->LOAD;
	uint32_t saved_ctrl = SysTick->CTRL;
	uint32_t ctl;

	SysTick->CTRL = 0;
	SysTick->LOAD = (uint32_t)(counts * counts_1us);
	SysTick->VAL  = 0x0000U;
	SysTick->CTRL = SysTick_CTRL_ENABLE_Msk;

	do{
		ctl = SysTick->CTRL;
	}while((ctl & SysTick_CTRL_ENABLE_Msk) && !(ctl & SysTick_CTRL_COUNTFLAG_Msk));

	// 恢复SysTick ISR配置
	SysTick->CTRL = 0;
	SysTick->LOAD = saved_load;
	SysTick->VAL  = 0x0000U;
	SysTick->CTRL = saved_ctrl;
}
 

