#include "delay.h"

#include "systick.h"
#include "gd32l23x.h"
#include "gd32l23x_rtc.h"
#include <stdio.h>
#include <stddef.h>
#include <string.h>
#include "tim.h"
#include "usart.h"

rtc_parameter_struct   rtc_initpara;
rtc_alarm_struct  rtc_alarm;
__IO uint32_t prescaler_a = 0, prescaler_s = 0;
uint32_t RTCSRC_FLAG = 0;

// RTC闹钟唤醒标志
volatile uint8_t rtc_alarm_flag = 0;

static void rtc_pre_config(void);

// BCD ↔ DEC 工具函数
uint8_t dec2bcd(uint8_t dec)
{
    return ((dec / 10) << 4) | (dec % 10);
}

uint8_t bcd2dec(uint8_t bcd)
{
    return ((bcd >> 4) * 10) + (bcd & 0x0F);
}

// ==============================
// RTC 总初始化（时钟+分频，不阻塞等待串口）
// 时间将由 rtc_set_from_cclk() 通过4G模块同步
// ==============================
void rtc_init_all(void)
{
    rcu_periph_clock_enable(RCU_PMU);
    rcu_periph_clock_enable(RCU_BKP);
    pmu_backup_write_enable();

    RTCSRC_FLAG = GET_BITS(RCU_BDCTL, 8, 9);
    rtc_pre_config();

    if(BKP_VALUE == RTC_BKP0 && RTCSRC_FLAG != 0x00) {
        printf_debug("[RTC] Already configured\r\n");
        rtc_show_time();
        printf_debug("\r\n");
    } else {
        printf_debug("[RTC] Not configured, will sync from 4G\r\n");
    }
    rcu_all_reset_flag_clear();
}

// ==============================
// 仅做时钟预配置（供外部调用）
// ==============================
void rtc_pre_config_only(void)
{
    rcu_periph_clock_enable(RCU_PMU);
    rcu_periph_clock_enable(RCU_BKP);
    pmu_backup_write_enable();
    rtc_pre_config();
}

// ==============================
// RTC 预配置（时钟/分频）
// ==============================
static void rtc_pre_config(void)
{
#if defined (RTC_CLOCK_SOURCE_IRC32K)
    rcu_osci_on(RCU_IRC32K);
    rcu_osci_stab_wait(RCU_IRC32K);
    rcu_rtc_clock_config(RCU_RTCSRC_IRC32K);
    prescaler_s = 0x13F;
    prescaler_a = 0x63;

#elif defined (RTC_CLOCK_SOURCE_LXTAL)
    rcu_osci_on(RCU_LXTAL);
    rcu_osci_stab_wait(RCU_LXTAL);
    rcu_rtc_clock_config(RCU_RTCSRC_LXTAL);
    prescaler_s = 0xFF;
    prescaler_a = 0x7F;
#endif

    rcu_periph_clock_enable(RCU_RTC);
    rtc_register_sync_wait();
}

// ==============================
// 从AT+CCLK?应答解析时间并设置RTC
// 输入格式: "26/04/17,09:37:11+32"
// +32 = 32个15分钟 = 8小时, 即模块返回的已经是UTC+8本地时间
// 如果末尾tz>0, 说明已包含时区偏移, 不再额外+8
// ==============================
int rtc_set_from_cclk(const char *cclk_str)
{
    int year, month, day, hour, min, sec, tz = 0;

    // 找到引号内容
    const char *p = cclk_str;
    while(*p && *p != '"') p++;
    if(*p == '"') p++;  // 跳过开头引号

    // 解析: 26/04/17,09:37:11+32  (tz部分可选)
    int n = sscanf(p, "%d/%d/%d,%d:%d:%d+%d",
                   &year, &month, &day, &hour, &min, &sec, &tz);
    if(n < 6)
    {
        // 也尝试负时区: 26/04/17,09:37:11-xx
        n = sscanf(p, "%d/%d/%d,%d:%d:%d-%d",
                   &year, &month, &day, &hour, &min, &sec, &tz);
        if(n >= 7) tz = -tz;  // 负时区
    }
    if(n < 6)
    {
        printf_debug("[RTC] CCLK parse failed: %s\r\n", cclk_str);
        return 0;
    }

    // 无条件+8小时
    hour += 8;
    if(hour >= 24)
    {
        hour -= 24;
        day += 1;
    }
    printf_debug("[RTC] Applied +8h offset\r\n");

    printf_debug("[RTC] CCLK parsed: 20%02d-%02d-%02d %02d:%02d:%02d\r\n",
                 year, month, day, hour, min, sec);

    // 配置RTC
    rtc_initpara.factor_asyn    = prescaler_a;
    rtc_initpara.factor_syn     = prescaler_s;
    rtc_initpara.display_format = RTC_24HOUR;
    rtc_initpara.am_pm          = RTC_AM;
    rtc_initpara.year           = dec2bcd((uint8_t)(year % 100));
    rtc_initpara.month          = dec2bcd((uint8_t)month);
    rtc_initpara.date           = dec2bcd((uint8_t)day);
    rtc_initpara.hour           = dec2bcd((uint8_t)hour);
    rtc_initpara.minute         = dec2bcd((uint8_t)min);
    rtc_initpara.second         = dec2bcd((uint8_t)sec);

    if(ERROR == rtc_init(&rtc_initpara))
    {
        printf_debug("[RTC] Init failed!\r\n");
        return 0;
    }

    RTC_BKP0 = BKP_VALUE;
    printf_debug("[RTC] Time set OK\r\n");
    rtc_show_time();
    printf_debug("\r\n");
    return 1;
}

// ==============================
// 显示当前时间
// ==============================
void rtc_show_time(void)
{
    rtc_current_time_get(&rtc_initpara);
    printf_debug("\rCurrent time: 20%0.2x-%0.2x-%0.2x %0.2x:%0.2x:%0.2x",
           rtc_initpara.year, rtc_initpara.month, rtc_initpara.date,
           rtc_initpara.hour, rtc_initpara.minute, rtc_initpara.second);
}

// ==============================
// 获取当前时间字符串 "20xx-xx-xx xx:xx:xx"
// ==============================
void rtc_get_time_str(char *buf, uint8_t buf_size)
{
    rtc_current_time_get(&rtc_initpara);
    snprintf(buf, buf_size, "20%02x-%02x-%02x %02x:%02x:%02x",
             rtc_initpara.year, rtc_initpara.month, rtc_initpara.date,
             rtc_initpara.hour, rtc_initpara.minute, rtc_initpara.second);
}

// ==============================
// RTC闹钟唤醒初始化
// 配置EXTI17 + NVIC使能RTC_Alarm中断
// ==============================
void rtc_alarm_wakeup_init(void)
{
    // EXTI17 = RTC Alarm事件线, 上升沿触发
    exti_init(EXTI_17, EXTI_INTERRUPT, EXTI_TRIG_RISING);
    exti_flag_clear(EXTI_17);

    // 使能RTC Alarm中断 (IRQ #57)
    nvic_irq_enable(RTC_Alarm_IRQn, 1);

    rtc_alarm_flag = 0;

    printf_debug("[RTC] Alarm wakeup init OK\r\n");
}

// ==============================
// 设置下一次RTC闹钟
// interval_minutes: 从当前时间往后N分钟触发
// ==============================
void rtc_set_next_alarm(uint16_t interval_minutes)
{
    rtc_alarm_struct alarm_cfg;
    rtc_parameter_struct cur_time;
    uint16_t total_min;
    uint8_t next_hour, next_min;

    // 读取当前时间
    rtc_current_time_get(&cur_time);

    uint8_t cur_hour = bcd2dec(cur_time.hour);
    uint8_t cur_min  = bcd2dec(cur_time.minute);

    // 计算下一次闹钟时间
    total_min = (uint16_t)cur_hour * 60 + cur_min + interval_minutes;
    next_hour = (uint8_t)((total_min / 60) % 24);
    next_min  = (uint8_t)(total_min % 60);

    // 先关闭闹钟0
    rtc_alarm_disable(RTC_ALARM0);

    // 配置闹钟: 匹配 时:分:秒=00, 屏蔽日期（每天都能触发）
    alarm_cfg.alarm_mask       = RTC_ALARM_DATE_MASK;     // 不比较日期
    alarm_cfg.weekday_or_date  = RTC_ALARM_DATE_SELECTED;
    alarm_cfg.alarm_day        = 0x01;
    alarm_cfg.am_pm            = RTC_AM;
    alarm_cfg.alarm_hour       = dec2bcd(next_hour);
    alarm_cfg.alarm_minute     = dec2bcd(next_min);
    alarm_cfg.alarm_second     = 0x00;

    rtc_alarm_config(RTC_ALARM0, &alarm_cfg);

    // 清除闹钟标志
    rtc_flag_clear(RTC_FLAG_ALARM0);
    exti_flag_clear(EXTI_17);

    // 使能闹钟中断
    rtc_interrupt_enable(RTC_INT_ALARM0);
    rtc_alarm_enable(RTC_ALARM0);

    // 清零唤醒标志
    rtc_alarm_flag = 0;

    printf_debug("[RTC] Next alarm: %02d:%02d:00 (in %d min)\r\n",
                 next_hour, next_min, interval_minutes);
}