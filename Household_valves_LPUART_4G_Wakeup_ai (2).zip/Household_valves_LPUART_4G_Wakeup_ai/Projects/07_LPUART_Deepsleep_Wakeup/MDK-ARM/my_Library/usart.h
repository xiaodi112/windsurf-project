#ifndef USART_H
#define USART_H

#include "gd32l23x.h"
#include "gd32l23x_libopt.h"
#include <stdbool.h>
#include <stdint.h>

int trea_uart_recv_byte_timeout(uint32_t uart, uint8_t* ch, uint32_t timeout_ms);
void trea_uart_init(void);
void lpuart_cat_uart_init(void);
int serial_write(uint32_t uart, const uint8_t *data, uint16_t len);
int lpuart_wait_for(const char *expect, uint32_t timeout_ms);
int printf_debug(const char* fmt, ...);
int printf_cat1(const char* fmt, ...);

// ===================== 【封装1】LPUART唤醒初始化 =====================
void lpuart_wakeup_init(void);
// ===================== 【封装2】进入深休眠 =====================
void enter_deepsleep_mode(void);
// ===================== 【封装3】唤醒后系统重新初始化 =====================
void system_wakeup_reinit(void);
// ===================== LPUART初始化 =====================
void com_lpuart_init(void);
extern __IO uint8_t counter0;  // LPUART唤醒标记

#endif
