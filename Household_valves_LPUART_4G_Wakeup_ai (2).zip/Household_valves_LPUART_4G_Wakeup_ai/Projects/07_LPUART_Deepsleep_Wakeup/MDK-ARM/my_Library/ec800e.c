/**
 * @file ec800e.c
 * @brief EC801E LTE Cat.1 模块驱动
 * @details AT指令驱动：电源、网络、MQTT、数据发布、时间同步
 *          MQTT参数从 g_mqtt 运行时配置读取（EEPROM保存）
 */

#include "ec800e.h"
#include "eeprom_config.h"
#include "app_config.h"
#include "usart.h"
#include "delay.h"
#include "tim.h"
#include <string.h>
#include <stdio.h>
#include "main.h"

// ==================== 内部: LPUART接收缓冲 ====================
char ec_rx_buf[256];
static uint16_t ec_rx_len = 0;

// ==================== 安全AT指令发送（防卡死） ====================
// 核心改进:
//   1) 用字节计数(最多256)限制，防RBNE不清除导致死循环
//   2) 每字节超时30ms，无数据+已收到部分内容即退出
//   3) 缓冲区满强制退出
// 应答保存到ec_rx_buf供外部解析
static EC_Status_t EC_SendCmd(const char *cmd, const char *expect, uint32_t timeout_ms)
{
    uint8_t ch;
    uint16_t cnt;
    uint32_t start;
    uint32_t byte_timeout;

    ec_rx_len = 0;
    ec_rx_buf[0] = '\0';

    printf_cat1("%s", cmd);

    // 每字节最长等30ms，但总时间不超过timeout_ms
    start = trea_millis();
    for(cnt = 0; cnt < sizeof(ec_rx_buf) - 1; cnt++)
    {
        // 总超时检查
        if((trea_millis() - start) >= timeout_ms)
            break;

        // 剩余时间不足30ms时，用剩余时间作为单字节超时
        byte_timeout = timeout_ms - (trea_millis() - start);
        if(byte_timeout > 30) byte_timeout = 30;

        if(trea_uart_recv_byte_timeout(LPUART0, &ch, byte_timeout))
        {
            ec_rx_buf[ec_rx_len++] = (char)ch;
            ec_rx_buf[ec_rx_len] = '\0';

            // 检查是否收到期望应答
            if(expect && strstr(ec_rx_buf, expect) != NULL)
                return EC_OK;
        }
        else
        {
            // 30ms内无数据:
            // 如果已经收到了一些字节但期望串没出现，可能模块已回完
            // 继续等（外层总超时会兜底）
        }
    }

    // 超时或缓冲区满
    return EC_TIMEOUT;
}

// 发送AT指令，失败重试（带总超时保护+智能提前退出）
static EC_Status_t EC_SendCmdRetry(const char *cmd, const char *expect,
                                   uint32_t timeout_ms, uint8_t max_retry)
{
    uint8_t i;
    uint8_t zero_rx_count = 0;  // 连续0字节应答计数

    for(i = 0; i < max_retry; i++)
    {
        if(EC_SendCmd(cmd, expect, timeout_ms) == EC_OK)
            return EC_OK;

        printf_debug("[EC] Retry %d/%d (got %d bytes): %s",
                     i + 1, max_retry, ec_rx_len, cmd);
        printf_debug("[EC] Response: %s\r\n", ec_rx_buf);

        // 如果连续2次完全没收到数据，说明模块可能掉了，提前退出
        if(ec_rx_len == 0)
        {
            zero_rx_count++;
            if(zero_rx_count >= 2)
            {
                printf_debug("[EC] Module not responding, abort\r\n");
                return EC_ERROR;
            }
        }
        else
        {
            zero_rx_count = 0;
        }

        trea_delay_ms(1000);
    }
    printf_debug("[EC] FAIL after %d retries: %s", max_retry, cmd);
    return EC_ERROR;
}

// ==================== 电源控制 ====================
void EC801E_PowerOn(void)
{
    gpio_bit_reset(EC_PWRKEY_PORT, EC_PWRKEY_PIN);
    trea_delay_ms(600);
    gpio_bit_set(EC_PWRKEY_PORT, EC_PWRKEY_PIN);
    trea_delay_ms(3000);
    printf_debug("[EC] Power ON\r\n");
}

void EC801E_PowerOff(void)
{
    gpio_bit_reset(EC_PWRKEY_PORT, EC_PWRKEY_PIN);
    trea_delay_ms(1000);
    gpio_bit_set(EC_PWRKEY_PORT, EC_PWRKEY_PIN);
    trea_delay_ms(2000);
    printf_debug("[EC] Power OFF\r\n");
}

// ==================== 网络初始化 ====================
EC_Status_t EC801E_InitNetwork(void)
{
    printf_debug("[EC] InitNetwork...\r\n");

    if(EC_SendCmdRetry("AT\r\n", "OK", APP_AT_TIMEOUT_SHORT, APP_EC_MAX_RETRY) != EC_OK)
        return EC_ERROR;

    if(EC_SendCmdRetry("AT+CPIN?\r\n", "READY", APP_AT_TIMEOUT_SHORT, APP_EC_MAX_RETRY) != EC_OK)
    {
        printf_debug("[EC] SIM not ready!\r\n");
        return EC_ERROR;
    }

    // SIM卡就绪，查询ICCID
    if(EC_SendCmd("AT+QCCID\r\n", "OK", APP_AT_TIMEOUT_SHORT) == EC_OK)
        printf_debug("[EC] %s\r\n", ec_rx_buf);
    else
        printf_debug("[EC] ICCID query failed\r\n");

	trea_delay_ms(1000);
    EC_SendCmd("AT+CSQ\r\n", "OK", APP_AT_TIMEOUT_SHORT);

    if(EC_SendCmdRetry("AT+CGACT=1,1\r\n", "OK", APP_AT_TIMEOUT_LONG, APP_EC_MAX_RETRY) != EC_OK)
    {
        printf_debug("[EC] Network activate failed!\r\n");
        return EC_ERROR;
    }

    printf_debug("[EC] Network ready\r\n");
    return EC_OK;
}

// ==================== 从4G模块同步网络时间到RTC ====================
EC_Status_t EC801E_SyncTime(void)
{
    uint8_t ch;
    uint16_t cnt;

    printf_debug("[EC] SyncTime start\r\n");

    // 1. 清空接收缓冲
    ec_rx_len = 0;
    ec_rx_buf[0] = '\0';

    // 2. 发送AT+CCLK?
    printf_cat1("AT+CCLK?\r\n");

    // 3. 读取应答（最多读200字节，每字节最长等30ms）
    //    RBNE在LPUART上可能不会被usart_data_receive清除，
    //    因此不能用"等到超时退出"的方式，必须用字节计数限制
    for(cnt = 0; cnt < 200; cnt++)
    {
        if(trea_uart_recv_byte_timeout(LPUART0, &ch, 30))
        {
            if(ec_rx_len < sizeof(ec_rx_buf) - 1)
            {
                ec_rx_buf[ec_rx_len++] = (char)ch;
                ec_rx_buf[ec_rx_len] = '\0';
            }
            // 找到完整的 OK 结尾就可以停了
            if(strstr(ec_rx_buf, "OK") != NULL)
                break;
        }
        else
        {
            // 30ms内无数据，如果已经有+CCLK:就够了
            if(strstr(ec_rx_buf, "+CCLK:") != NULL)
                break;
        }
    }

    printf_debug("[EC] CCLK raw(%d): %s\r\n", ec_rx_len, ec_rx_buf);

    // 4. 解析
    {
        char *p = strstr(ec_rx_buf, "+CCLK:");
        if(!p)
        {
            printf_debug("[EC] SyncTime: no +CCLK in response\r\n");
            return EC_ERROR;
        }

        if(rtc_set_from_cclk(p))
            return EC_OK;
    }

    return EC_ERROR;
}

// ==================== MQTT连接（使用g_mqtt运行时配置） ====================
EC_Status_t EC801E_ConnectMQTT(void)
{
    static char cmd_buf[256];

    printf_debug("[EC] ConnectMQTT...\r\n");

    // 断开旧连接
    printf_cat1("AT+QMTDISC=0\r\n");
    trea_delay_ms(500);
    printf_cat1("AT+QMTCLOSE=0\r\n");
    trea_delay_ms(500);

    // 打开MQTT连接（使用g_mqtt中的server和port）
    snprintf(cmd_buf, sizeof(cmd_buf),
             "AT+QMTOPEN=0,\"%s\",%d\r\n", g_mqtt.server, g_mqtt.port);
    if(EC_SendCmdRetry(cmd_buf, "+QMTOPEN: 0,0", APP_AT_TIMEOUT_MQTT, APP_EC_MAX_RETRY) != EC_OK)
    {
        printf_debug("[EC] MQTT open failed!\r\n");
        return EC_ERROR;
    }

    trea_delay_ms(500);

    // 连接MQTT服务器（使用g_mqtt中的client_id/username/password）
    // 注: QMTCONN的URC(+QMTCONN:)在LPUART上容易丢字节，
    //     改为先等OK确认命令已接受，再用QMTCONN?查询连接状态
    snprintf(cmd_buf, sizeof(cmd_buf),
             "AT+QMTCONN=0,\"%s\",\"%s\",\"%s\"\r\n",
             g_mqtt.client_id, g_mqtt.username, g_mqtt.password);
    if(EC_SendCmd(cmd_buf, "OK", APP_AT_TIMEOUT_MQTT) != EC_OK)
    {
        printf_debug("[EC] MQTT CONN cmd rejected\r\n");
        return EC_ERROR;
    }

    // 等待服务器握手完成
    trea_delay_ms(3000);

    // 查询连接状态 (state=3 表示已连接)
    if(EC_SendCmd("AT+QMTCONN?\r\n", "+QMTCONN: 0,3", APP_AT_TIMEOUT_SHORT) == EC_OK)
    {
        printf_debug("[EC] MQTT connected (verified)\r\n");
        return EC_OK;
    }

    printf_debug("[EC] MQTT connect failed (state != 3)\r\n");
    printf_debug("[EC] Response: %s\r\n", ec_rx_buf);
    return EC_ERROR;
}

// ==================== MQTT断开 ====================
EC_Status_t EC801E_DisconnectMQTT(void)
{
    trea_delay_ms(300);
    EC_SendCmd("AT+QMTDISC=0\r\n", "OK", APP_AT_TIMEOUT_SHORT);
    return EC_OK;
}

// ==================== 发布传感器数据 ====================
EC_Status_t EC801E_PublishSensorData(PT304D_Data *data)
{
    static char payload[512];
    static char timestamp[32];
    static char cmd_buf[256];
    uint16_t payload_len;

    if(!data) return EC_ERROR;

    rtc_get_time_str(timestamp, sizeof(timestamp));
//	trea_delay_ms(10);
	printf_debug("\"ts\":\"%s\"",timestamp);

    // 构建FastBee格式JSON
    snprintf(payload, sizeof(payload),
        "[{\"id\":\"voltage\",\"value\":\"%.2f\",\"ts\":\"%s\",\"remark\":\"\"},"
		 "{\"id\":\"pressure\",\"value\":\"%.2f\",\"ts\":\"%s\",\"remark\":\"\"},"
         "{\"id\":\"temp\",\"value\":\"%.2f\",\"ts\":\"%s\",\"remark\":\"\"}]",
        voltage1, timestamp,
		pressure1, timestamp,
        temperature1, timestamp);

    payload_len = (uint16_t)strlen(payload);

    // 使用g_mqtt中的topic
    snprintf(cmd_buf, sizeof(cmd_buf),
             "AT+QMTPUBEX=0,0,0,0,\"%s\",%d\r\n", g_mqtt.topic_up, payload_len);
    printf_cat1("%s", cmd_buf);

    if(!lpuart_wait_for(">", APP_AT_TIMEOUT_SHORT))
    {
        printf_debug("[EC] Publish: no '>' prompt\r\n");
        return EC_TIMEOUT;
    }
    trea_delay_ms(1000);
    printf_cat1("%s", payload);


    printf_debug("[EC] Publish OK: P=%.2f T=%.2f\r\n", data->pressure, data->temperature);
    return EC_OK;
}

// ==================== 完整上报流程 ====================
EC_Status_t EC801E_FullUpload(PT304D_Data *data)
{
    uint8_t retry;
    EC_Status_t ret;

    EC801E_SetPSM(0);
    trea_delay_ms(1000);

    printf_debug("[EC] === FullUpload start ===\r\n");

    for(retry = 0; retry < APP_EC_MAX_RETRY; retry++)
    {
        ret = EC801E_InitNetwork();
        if(ret != EC_OK)
        {
            printf_debug("[EC] InitNetwork fail, retry %d/%d\r\n", retry + 1, APP_EC_MAX_RETRY);
            trea_delay_ms(2000);
            continue;
        }

        ret = EC801E_ConnectMQTT();
        if(ret != EC_OK)
        {
            printf_debug("[EC] ConnectMQTT fail, retry %d/%d\r\n", retry + 1, APP_EC_MAX_RETRY);
            trea_delay_ms(2000);
            continue;
        }

        ret = EC801E_PublishSensorData(data);
        if(ret != EC_OK)
        {
            printf_debug("[EC] Publish fail, retry %d/%d\r\n", retry + 1, APP_EC_MAX_RETRY);
            EC801E_DisconnectMQTT();
            trea_delay_ms(2000);
            continue;
        }

        trea_delay_ms(1000);
        EC801E_DisconnectMQTT();
        trea_delay_ms(500);
        EC801E_SetPSM(1);

        printf_debug("[EC] === FullUpload success ===\r\n");
        return EC_OK;
    }

    printf_debug("[EC] === FullUpload FAILED after %d retries ===\r\n", APP_EC_MAX_RETRY);
    EC801E_DisconnectMQTT();
    return EC_ERROR;
}

// ==================== 模块休眠模式设置 ====================
// mode=0: 关闭休眠
// mode=1: QSCLK轻休眠(保持网络+MQTT, UART可唤醒)
// mode=3: PSM深休眠(脱网, T3412周期唤醒, UART可唤醒)
void EC801E_SetPSM(uint8_t mode)
{
    switch(mode)
    {
        case 3:
            // PSM: T3412=1分钟(10100001), T3324=20秒(00001010)
            EC_SendCmd("AT+CPSMS=1,,,\"10100001\",\"00001010\"\r\n", "OK", APP_AT_TIMEOUT_SHORT);
            EC_SendCmd("AT+QSCLK=3\r\n", "OK", APP_AT_TIMEOUT_SHORT);
            printf_debug("[EC] PSM enabled (TAU=1min, Active=20s)\r\n");
            break;
        case 1:
            EC_SendCmd("AT+CPSMS=0\r\n", "OK", APP_AT_TIMEOUT_SHORT);
            EC_SendCmd("AT+QSCLK=2\r\n", "OK", APP_AT_TIMEOUT_SHORT);
            printf_debug("[EC] QSCLK=2 (light sleep, MQTT kept)\r\n");
            break;
        default:
            EC_SendCmd("AT+QSCLK=0\r\n", "OK", APP_AT_TIMEOUT_SHORT);
            EC_SendCmd("AT+CPSMS=0\r\n", "OK", APP_AT_TIMEOUT_SHORT);
            printf_debug("[EC] Sleep disabled\r\n");
            break;
    }
}

// ==================== 唤醒模块（QSCLK=1模式下首字节可能丢失） ====================
void EC801E_Wakeup(void)
{
    printf_cat1("AT\r\n");
    trea_delay_ms(100);
    EC_SendCmd("AT\r\n", "OK", APP_AT_TIMEOUT_SHORT);
    printf_debug("[EC] Module wakeup\r\n");
}

// ==================== MQTT订阅下发topic ====================
EC_Status_t EC801E_SubscribeTopic(void)
{
    static char cmd_buf[256];
    static char topic_down[MQTT_TOPIC_MAX];

    // 从上报topic推导订阅topic: /property/post → /function/get
    strncpy(topic_down, g_mqtt.topic_up, sizeof(topic_down) - 1);
    topic_down[sizeof(topic_down) - 1] = '\0';
    {
        char *p = strstr(topic_down, "/property/post");
        if(p) {
            memcpy(p, "/function/get", 13);
            *(p + 13) = '\0';
        }
    }

    snprintf(cmd_buf, sizeof(cmd_buf),
             "AT+QMTSUB=0,1,\"%s\",0\r\n", topic_down);

    if(EC_SendCmdRetry(cmd_buf, "OK", APP_AT_TIMEOUT_MQTT, APP_EC_MAX_RETRY) != EC_OK)
    {
        printf_debug("[EC] Subscribe failed!\r\n");
        return EC_ERROR;
    }

    printf_debug("[EC] Subscribed: %s\r\n", topic_down);
    return EC_OK;
}

// ==================== 读取MQTT下发消息(主动查询) ====================
// LPUART唤醒时URC已丢失(system_wakeup_reinit禁用了LPUART)
// 因此使用AT+QMTRECV主动查询模块缓存的消息(需配合recv/mode=1)
EC_Status_t EC801E_ReadDownlink(char *payload_buf, uint16_t buf_size)
{
    char *json;
    char *json_end;
    char end_ch;
    uint16_t len;

    payload_buf[0] = '\0';

    // 唤醒模块(QSCLK=2下首字节可能丢失)
    EC801E_Wakeup();

    // 主动查询缓存的下发消息
    if(EC_SendCmd("AT+QMTRECV=0\r\n", "+QMTRECV:", APP_AT_TIMEOUT_MQTT) != EC_OK)
    {
        printf_debug("[EC] No buffered downlink\r\n");
        return EC_TIMEOUT;
    }

    printf_debug("[EC] QMTRECV(%d): %s\r\n", ec_rx_len, ec_rx_buf);

    // 提取JSON payload: 找 [ ... ] 或 { ... }
    json = strchr(ec_rx_buf, '[');
    if(!json) json = strchr(ec_rx_buf, '{');
    if(!json) { printf_debug("[EC] No JSON in downlink\r\n"); return EC_ERROR; }

    end_ch = (*json == '[') ? ']' : '}';
    json_end = strrchr(json, end_ch);
    if(!json_end) { printf_debug("[EC] Incomplete JSON\r\n"); return EC_ERROR; }

    len = (uint16_t)(json_end - json + 1);
    if(len >= buf_size) len = buf_size - 1;
    memcpy(payload_buf, json, len);
    payload_buf[len] = '\0';

    printf_debug("[EC] Downlink: %s\r\n", payload_buf);
    return EC_OK;
}

// ==================== 等待模块注网（PSM唤醒后需要） ====================
static EC_Status_t EC801E_WaitNetwork(uint8_t max_seconds)
{
    uint8_t i;
    for(i = 0; i < max_seconds; i++)
    {
        // +CREG: 0,1=已注册(本地), 0,5=已注册(漫游)
        if(EC_SendCmd("AT+CREG?\r\n", ",1", APP_AT_TIMEOUT_SHORT) == EC_OK)
        {
            printf_debug("[EC] Network registered (%ds)\r\n", i);
            return EC_OK;
        }
        if(EC_SendCmd("AT+CREG?\r\n", ",5", APP_AT_TIMEOUT_SHORT) == EC_OK)
        {
            printf_debug("[EC] Network registered roaming (%ds)\r\n", i);
            return EC_OK;
        }
        trea_delay_ms(1000);
    }
    printf_debug("[EC] Network register timeout\r\n");
    return EC_TIMEOUT;
}

// ==================== 确保MQTT已连接（QSCLK=1模式，断线自动重连） ====================
EC_Status_t EC801E_EnsureConnected(void)
{
    EC801E_Wakeup();

    // 查询MQTT连接状态 (state=3表示已连接)
    if(EC_SendCmd("AT+QMTCONN?\r\n", "+QMTCONN: 0,3", APP_AT_TIMEOUT_SHORT) == EC_OK)
    {
        printf_debug("[EC] MQTT still connected\r\n");
        return EC_OK;
    }

    printf_debug("[EC] MQTT disconnected, reconnecting...\r\n");
    return EC801E_InitAndConnect();
}

// ==================== 首次初始化+连接+订阅+QSCLK ====================
EC_Status_t EC801E_InitAndConnect(void)
{
    static char cmd[128];
    uint8_t retry;
    EC_Status_t ret;

    EC801E_SetPSM(0);
    trea_delay_ms(500);

    printf_debug("[EC] === InitAndConnect ===\r\n");

    for(retry = 0; retry < APP_EC_MAX_RETRY; retry++)
    {
        ret = EC801E_InitNetwork();
        if(ret != EC_OK) { trea_delay_ms(2000); continue; }

        // 设置keepalive (从阈值配置或默认值)
        {
            extern uint16_t threshold_get_keepalive(void);
            uint16_t ka = threshold_get_keepalive();
            snprintf(cmd, sizeof(cmd), "AT+QMTCFG=\"keepalive\",0,%d\r\n", ka);
            EC_SendCmd(cmd, "OK", APP_AT_TIMEOUT_SHORT);
        }

        // 消息缓存模式: 模块收到下发后缓存, MCU用AT+QMTRECV主动查询
        // (LPUART唤醒时URC会丢失, 必须用主动查询)
        EC_SendCmd("AT+QMTCFG=\"recv/mode\",0,1,0\r\n", "OK", APP_AT_TIMEOUT_SHORT);

        ret = EC801E_ConnectMQTT();
        if(ret != EC_OK) { trea_delay_ms(2000); continue; }

        trea_delay_ms(1000);

        // 订阅下发topic
        EC801E_SubscribeTopic();

        // 同步时间
        trea_delay_ms(500);
        EC801E_SyncTime();

        // 启用QSCLK (模块自动休眠, 保持网络+MQTT)
        trea_delay_ms(500);
        EC801E_SetPSM(1);

        printf_debug("[EC] === Connected & QSCLK=1 ===\r\n");
        return EC_OK;
    }

    printf_debug("[EC] === InitAndConnect FAILED ===\r\n");
    return EC_ERROR;
}

// ==================== 发布单条历史记录 ====================
EC_Status_t EC801E_PublishSingleRecord(const SensorRecord_t *record)
{
    static char payload[512];
    static char cmd_buf[256];
    uint16_t payload_len;

    if(!record) return EC_ERROR;

    snprintf(payload, sizeof(payload),
        "[{\"id\":\"voltage\",\"value\":\"%.2f\",\"ts\":\"%s\",\"remark\":\"\"},"
         "{\"id\":\"pressure\",\"value\":\"%.2f\",\"ts\":\"%s\",\"remark\":\"\"},"
         "{\"id\":\"temp\",\"value\":\"%.2f\",\"ts\":\"%s\",\"remark\":\"\"}]",
        record->voltage, record->timestamp,
        record->pressure, record->timestamp,
        record->temperature, record->timestamp);

    payload_len = (uint16_t)strlen(payload);

    snprintf(cmd_buf, sizeof(cmd_buf),
             "AT+QMTPUBEX=0,0,0,0,\"%s\",%d\r\n", g_mqtt.topic_up, payload_len);
    printf_cat1("%s", cmd_buf);

    if(!lpuart_wait_for(">", APP_AT_TIMEOUT_SHORT))
    {
        printf_debug("[EC] Record publish: no '>'\r\n");
        return EC_TIMEOUT;
    }
    trea_delay_ms(100);
    printf_cat1("%s", payload);

    printf_debug("[EC] Record: P=%.2f T=%.2f V=%.2f @%s\r\n",
                 record->pressure, record->temperature, record->voltage, record->timestamp);
    return EC_OK;
}

// ==================== 发布报警消息 ====================
EC_Status_t EC801E_PublishAlarm(const char *alarm_type, float pressure, float voltage)
{
    static char payload[512];
    static char timestamp[32];
    static char cmd_buf[256];
    uint16_t payload_len;

    rtc_get_time_str(timestamp, sizeof(timestamp));

    snprintf(payload, sizeof(payload),
        "[{\"id\":\"alarm\",\"value\":\"%s\",\"ts\":\"%s\",\"remark\":\"P=%.2f V=%.2f\"},"
         "{\"id\":\"pressure\",\"value\":\"%.2f\",\"ts\":\"%s\",\"remark\":\"\"},"
         "{\"id\":\"voltage\",\"value\":\"%.2f\",\"ts\":\"%s\",\"remark\":\"\"}]",
        alarm_type, timestamp, pressure, voltage,
        pressure, timestamp,
        voltage, timestamp);

    payload_len = (uint16_t)strlen(payload);

    snprintf(cmd_buf, sizeof(cmd_buf),
             "AT+QMTPUBEX=0,0,0,0,\"%s\",%d\r\n", g_mqtt.topic_up, payload_len);
    printf_cat1("%s", cmd_buf);

    if(!lpuart_wait_for(">", APP_AT_TIMEOUT_SHORT))
    {
        printf_debug("[EC] Alarm publish: no '>'\r\n");
        return EC_TIMEOUT;
    }
    trea_delay_ms(100);
    printf_cat1("%s", payload);

    printf_debug("[EC] ALARM published: %s P=%.2f V=%.2f\r\n", alarm_type, pressure, voltage);
    return EC_OK;
}

// ==================== 发布下发响应 ====================
EC_Status_t EC801E_PublishResponse(const char *id, const char *value)
{
    static char payload[256];
    static char cmd_buf[256];
    uint16_t payload_len;

    snprintf(payload, sizeof(payload),
        "[{\"id\":\"%s\",\"value\":\"%s\"}]", id, value);

    payload_len = (uint16_t)strlen(payload);

    snprintf(cmd_buf, sizeof(cmd_buf),
             "AT+QMTPUBEX=0,0,0,0,\"%s\",%d\r\n", g_mqtt.topic_up, payload_len);
    printf_cat1("%s", cmd_buf);

    if(!lpuart_wait_for(">", APP_AT_TIMEOUT_SHORT))
    {
        printf_debug("[EC] Response publish: no '>'\r\n");
        return EC_TIMEOUT;
    }
    trea_delay_ms(100);
    printf_cat1("%s", payload);

    printf_debug("[EC] Response: %s=%s\r\n", id, value);
    return EC_OK;
}

