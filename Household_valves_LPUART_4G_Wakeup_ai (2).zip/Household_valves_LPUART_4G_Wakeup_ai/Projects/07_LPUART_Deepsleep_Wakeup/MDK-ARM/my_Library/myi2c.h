#ifndef MYI2C__H
#define MYI2C__H

#include "gd32l23x.h"  // GD32L233��׼��ͷ�ļ�

#define IIC_WR    0     /* д����bit */
#define IIC_RD    1     /* ������bit */

void IIC_Start1(void);
void IIC_Stop1(void);
void IIC_Send_Byte1(uint8_t _ucByte);
uint8_t IIC_Read_Byte1(uint8_t ack);
uint8_t IIC_Wait_Ack1(void);
void IIC_Ack1(void);
void IIC_NAck1(void);
uint8_t IIC_CheckDevice1(uint8_t _Address);
void IIC_GPIO_Init1(void);



#endif
