#ifndef TREA_TIME_H
#define TREA_TIME_H

#include <stdint.h>
#include <stdio.h>

// ʱ��ṹ�壨�����ֱ���ã�
typedef struct {
    uint16_t year;    // �� 20xx
    uint8_t  month;   // ��
    uint8_t  day;     // ��
    uint8_t  hour;    // ʱ
    uint8_t  min;     // ��
    uint8_t  sec;     // ��
    uint8_t  week;    // ����
} SysTime_TypeDef;

void trea_time_isr(void);
uint32_t trea_millis(void);
void trea_delay_ms(uint32_t ms);
void delay_us(uint32_t us);


void my_systick_config(void);
/*ms*/
void my_systick_delay_ms(uint32_t counts);
/*us*/
void my_systick_delay_us(uint32_t counts);

#endif
