#include "i2c_cz.h"
#include "delay.h"

void IIC_Delay(void)
{
    volatile uint16_t i;
    for(i = 0; i < 100; i++);
}

void IIC_Init(void)
{
    /* 1. 先使能GPIO时钟 */
    RCC_IIC_ENABLE;

    /* 2. 配置GPIO模式：开漏输出 + 上拉电阻（I2C总线强制要求） */
    gpio_mode_set(GPIO_PORT_IIC, GPIO_MODE_OUTPUT, GPIO_PUPD_PULLUP, IIC_SCL_PIN | IIC_SDA_PIN);
    gpio_output_options_set(GPIO_PORT_IIC, GPIO_OTYPE_OD, GPIO_OSPEED_50MHZ, IIC_SCL_PIN | IIC_SDA_PIN);

    /* 3. 初始化引脚为高电平，产生停止信号复位总线 */
    IIC_SCL_H();
    IIC_SDA_H();
    IIC_Delay();
    IIC_Stop();
}

/*
 * START: SDA下降沿（SCL为高时）
 * 时序: SDA=H,SCL=H → SDA=L → SCL=L
 */
void IIC_Start(void)
{
    IIC_SDA_H();
    IIC_SCL_H();
    IIC_Delay();
    IIC_SDA_L();    // SDA下降沿 = START
    IIC_Delay();
    IIC_SCL_L();    // 拉低SCL，准备数据传输
    IIC_Delay();
}

/*
 * STOP: SDA上升沿（SCL为高时）
 * 时序: SCL=L,SDA=L → SCL=H → SDA=H
 */
void IIC_Stop(void)
{
    IIC_SCL_L();
    IIC_SDA_L();
    IIC_Delay();
    IIC_SCL_H();
    IIC_Delay();
    IIC_SDA_H();    // SDA上升沿 = STOP
    IIC_Delay();
}

/*
 * 发送1字节（高位先行）
 * 时序: SCL=L时设置SDA → SCL=H锁存数据 → SCL=L
 */
void IIC_Send_Byte(uint8_t txd)
{
    int8_t i;

    for(i = 7; i >= 0; i--)
    {
        IIC_SCL_L();    // SCL拉低，安全切换SDA
        if(txd & BIT(i)) IIC_SDA_H();
        else IIC_SDA_L();
        IIC_Delay();
        IIC_SCL_H();    // SCL拉高，从机采样
        IIC_Delay();
    }
    IIC_SCL_L();
    IIC_SDA_H();        // 释放SDA，准备接收ACK
    IIC_Delay();
}

/*
 * 等待ACK应答
 * 时序: 释放SDA → SCL=H → 读SDA(0=ACK) → SCL=L
 */
uint8_t IIC_Wait_Ack(int16_t timeout)
{
    (void)timeout;

    IIC_SDA_H();        // 释放SDA，让从机驱动
    IIC_Delay();
    IIC_SCL_H();        // ACK时钟脉冲
    IIC_Delay();

    if(IIC_SDA_READ() != 0)
    {
        IIC_SCL_L();
        return 1;       // NACK
    }

    IIC_SCL_L();
    IIC_Delay();
    return 0;           // ACK
}

/*
 * 读取1字节（高位先行）
 * ack=1发送ACK继续读, ack=0发送NACK结束读
 */
uint8_t IIC_Read_Byte(uint8_t ack)
{
    int8_t i;
    uint8_t rxd = 0;

    IIC_SDA_H();        // 释放SDA，让从机驱动数据

    for(i = 7; i >= 0; i--)
    {
        IIC_SCL_L();
        IIC_Delay();
        IIC_SCL_H();
        IIC_Delay();
        if(IIC_SDA_READ()) rxd |= BIT(i);
    }
    IIC_SCL_L();
    IIC_Delay();

    // 发送ACK或NACK
    if(ack)
        IIC_SDA_L();    // ACK: SDA=0
    else
        IIC_SDA_H();    // NACK: SDA=1

    IIC_Delay();
    IIC_SCL_H();
    IIC_Delay();
    IIC_SCL_L();
    IIC_SDA_H();        // 释放SDA
    IIC_Delay();

    return rxd;
}









































