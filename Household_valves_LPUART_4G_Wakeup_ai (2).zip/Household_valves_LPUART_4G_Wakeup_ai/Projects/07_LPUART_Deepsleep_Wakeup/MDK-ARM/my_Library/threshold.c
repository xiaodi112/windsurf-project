/**
 * @file threshold.c
 * @brief 阈值检查模块实现
 *
 * 从EEPROM加载/保存阈值配置, 提供压力/电压上下限和突变检测
 */

#include "threshold.h"
#include "AT24c16.h"
#include "app_config.h"
#include "usart.h"
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <math.h>

// EEPROM地址 (与eeprom_config.h中的EE_ADDR_THRESHOLD_xxx对应)
#define EE_ADDR_THRESH_MAGIC      0x1B0
#define EE_ADDR_THRESH_PMIN       0x1B1   // float, 4B
#define EE_ADDR_THRESH_PMAX       0x1B5   // float, 4B
#define EE_ADDR_THRESH_VMIN       0x1B9   // float, 4B
#define EE_ADDR_THRESH_VMAX       0x1BD   // float, 4B
#define EE_ADDR_THRESH_MUTATION   0x1C1   // float, 4B
#define EE_ADDR_THRESH_KEEPALIVE  0x1C5   // uint16_t, 2B

#define EE_MAGIC_THRESHOLD        0xC3

// ==================== 全局变量 ====================
ThresholdConfig_t g_threshold;

// ==================== 内部工具 ====================
static float ee_read_float(uint16_t addr)
{
    float val = 0;
    AT24C16_Read(addr, (uint8_t *)&val, sizeof(float));
    return val;
}

static void ee_write_float(uint16_t addr, float val)
{
    AT24C16_Write(addr, (const uint8_t *)&val, sizeof(float));
}

// 从字符串提取 key:value
static int extract_val(const char *src, const char *key, char *out, uint16_t out_size)
{
    char search[32];
    snprintf(search, sizeof(search), "%s:", key);
    const char *p = strstr(src, search);
    if(!p) return 0;
    p += strlen(search);
    uint16_t i = 0;
    while(*p && *p != ',' && *p != '}' && i < out_size - 1)
        out[i++] = *p++;
    out[i] = '\0';
    return (i > 0) ? 1 : 0;
}

// ==================== 阈值检查 ====================
ThresholdResult_t threshold_check(float pressure, float voltage, float last_pressure)
{
    // 上下限检查
    if(pressure < g_threshold.pressure_min || pressure > g_threshold.pressure_max)
        return THRESHOLD_OVER_LIMIT;
    if(voltage < g_threshold.voltage_min || voltage > g_threshold.voltage_max)
        return THRESHOLD_OVER_LIMIT;

    // 突变检测 (last_pressure < 0 表示首次采集,跳过)
    if(last_pressure >= 0)
    {
        float delta = pressure - last_pressure;
        if(delta < 0) delta = -delta;
        if(delta > g_threshold.mutation_delta)
            return THRESHOLD_MUTATION;
    }

    return THRESHOLD_OK;
}

// ==================== 从EEPROM加载 ====================
void threshold_load(void)
{
    uint8_t magic = 0;
    AT24C16_Read(EE_ADDR_THRESH_MAGIC, &magic, 1);

    if(magic == EE_MAGIC_THRESHOLD)
    {
        g_threshold.pressure_min  = ee_read_float(EE_ADDR_THRESH_PMIN);
        g_threshold.pressure_max  = ee_read_float(EE_ADDR_THRESH_PMAX);
        g_threshold.voltage_min   = ee_read_float(EE_ADDR_THRESH_VMIN);
        g_threshold.voltage_max   = ee_read_float(EE_ADDR_THRESH_VMAX);
        g_threshold.mutation_delta = ee_read_float(EE_ADDR_THRESH_MUTATION);
        AT24C16_Read(EE_ADDR_THRESH_KEEPALIVE, (uint8_t *)&g_threshold.keepalive_sec, 2);

        printf_debug("[THR] EEPROM loaded: P[%.1f,%.1f] V[%.1f,%.1f] mut=%.2f ka=%d\r\n",
                     g_threshold.pressure_min, g_threshold.pressure_max,
                     g_threshold.voltage_min, g_threshold.voltage_max,
                     g_threshold.mutation_delta, g_threshold.keepalive_sec);
    }
    else
    {
        // 使用编译时默认值
        g_threshold.pressure_min   = APP_DEFAULT_PRESSURE_MIN;
        g_threshold.pressure_max   = APP_DEFAULT_PRESSURE_MAX;
        g_threshold.voltage_min    = APP_DEFAULT_VOLTAGE_MIN;
        g_threshold.voltage_max    = APP_DEFAULT_VOLTAGE_MAX;
        g_threshold.mutation_delta = APP_DEFAULT_MUTATION_DELTA;
        g_threshold.keepalive_sec  = APP_MQTT_KEEPALIVE;
        printf_debug("[THR] No EEPROM threshold, using defaults\r\n");
    }
}

// ==================== 保存到EEPROM ====================
void threshold_save(void)
{
    uint8_t magic = EE_MAGIC_THRESHOLD;
    AT24C16_WriteByte(EE_ADDR_THRESH_MAGIC, magic);
    ee_write_float(EE_ADDR_THRESH_PMIN,      g_threshold.pressure_min);
    ee_write_float(EE_ADDR_THRESH_PMAX,      g_threshold.pressure_max);
    ee_write_float(EE_ADDR_THRESH_VMIN,      g_threshold.voltage_min);
    ee_write_float(EE_ADDR_THRESH_VMAX,      g_threshold.voltage_max);
    ee_write_float(EE_ADDR_THRESH_MUTATION,  g_threshold.mutation_delta);
    AT24C16_Write(EE_ADDR_THRESH_KEEPALIVE, (const uint8_t *)&g_threshold.keepalive_sec, 2);

    printf_debug("[THR] Saved: P[%.1f,%.1f] V[%.1f,%.1f] mut=%.2f ka=%d\r\n",
                 g_threshold.pressure_min, g_threshold.pressure_max,
                 g_threshold.voltage_min, g_threshold.voltage_max,
                 g_threshold.mutation_delta, g_threshold.keepalive_sec);
}

// ==================== 解析配置字符串 ====================
int threshold_parse(const char *str)
{
    char val_buf[16];
    int changed = 0;

    if(extract_val(str, "pmin", val_buf, sizeof(val_buf)))
    { g_threshold.pressure_min = (float)atof(val_buf); changed = 1; }

    if(extract_val(str, "pmax", val_buf, sizeof(val_buf)))
    { g_threshold.pressure_max = (float)atof(val_buf); changed = 1; }

    if(extract_val(str, "vmin", val_buf, sizeof(val_buf)))
    { g_threshold.voltage_min = (float)atof(val_buf); changed = 1; }

    if(extract_val(str, "vmax", val_buf, sizeof(val_buf)))
    { g_threshold.voltage_max = (float)atof(val_buf); changed = 1; }

    if(extract_val(str, "mutation", val_buf, sizeof(val_buf)))
    { g_threshold.mutation_delta = (float)atof(val_buf); changed = 1; }

    if(extract_val(str, "keepalive", val_buf, sizeof(val_buf)))
    { g_threshold.keepalive_sec = (uint16_t)atoi(val_buf); changed = 1; }

    if(changed)
        threshold_save();

    return changed;
}

// ==================== 获取keepalive ====================
uint16_t threshold_get_keepalive(void)
{
    if(g_threshold.keepalive_sec < 30)
        return APP_MQTT_KEEPALIVE;  // 最小30秒,防无效值
    return g_threshold.keepalive_sec;
}
