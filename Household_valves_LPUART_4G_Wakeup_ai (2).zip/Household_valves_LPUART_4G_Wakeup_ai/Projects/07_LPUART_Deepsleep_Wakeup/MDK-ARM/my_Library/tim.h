#ifndef TIM_H
#define TIM_H

#include <stdint.h>
#include <stdio.h>
#include "gd32l23x.h"

// 时钟源选择
#define RTC_CLOCK_SOURCE_LXTAL
//#define RTC_CLOCK_SOURCE_IRC32K

#define BKP_VALUE    0x32F0

// ==============================
// RTC 基础功能
// ==============================
void rtc_init_all(void);
void rtc_pre_config_only(void);
void rtc_show_time(void);

// 从AT+CCLK?应答解析时间并设置RTC
// 输入格式: "26/04/17,09:37:11+32" (自动+8小时)
// 返回: 1=成功, 0=解析失败
int rtc_set_from_cclk(const char *cclk_str);

// ==============================
// RTC 闹钟唤醒功能（低功耗定时唤醒）
// ==============================
void rtc_alarm_wakeup_init(void);
void rtc_set_next_alarm(uint16_t interval_minutes);
void rtc_get_time_str(char *buf, uint8_t buf_size);

// RTC闹钟唤醒标志（中断中置1）
extern volatile uint8_t rtc_alarm_flag;

// BCD ↔ DEC 工具
uint8_t bcd2dec(uint8_t bcd);
uint8_t dec2bcd(uint8_t dec);

#endif










