#include "usart.h"

#include "delay.h"
#include "systick.h"
#include <stdarg.h>
#include <stdio.h>
#include <string.h>

static void system_clock_reconfig(void);

#define TREA_UART_DEBUG USART0
#define TREA_UART_CAT1  LPUART0

static void trea_uart_send_byte(uint32_t uart, uint8_t ch)
{
    usart_data_transmit(uart, ch);
    while(RESET == usart_flag_get(uart, USART_FLAG_TBE)) {
    }
}

int trea_uart_recv_byte_timeout(uint32_t uart, uint8_t* ch, uint32_t timeout_ms)
{
    uint32_t start = trea_millis();
    while((trea_millis() - start) < timeout_ms) {
        if(RESET != usart_flag_get(uart, USART_FLAG_RBNE)) {
            *ch = (uint8_t)usart_data_receive(uart);
            return 1;
        }
    }
    return 0;
}

void trea_uart_init(void)
{
    rcu_periph_clock_enable(RCU_GPIOC);
    rcu_periph_clock_enable(RCU_USART0);

    gpio_af_set(GPIOC, GPIO_AF_7, GPIO_PIN_4);
    gpio_af_set(GPIOC, GPIO_AF_7, GPIO_PIN_5);
    gpio_mode_set(GPIOC, GPIO_MODE_AF, GPIO_PUPD_PULLUP, GPIO_PIN_4);
    gpio_output_options_set(GPIOC, GPIO_OTYPE_PP, GPIO_OSPEED_10MHZ, GPIO_PIN_4);
    gpio_mode_set(GPIOC, GPIO_MODE_AF, GPIO_PUPD_PULLUP, GPIO_PIN_5);
    gpio_output_options_set(GPIOC, GPIO_OTYPE_PP, GPIO_OSPEED_10MHZ, GPIO_PIN_5);

    usart_deinit(TREA_UART_DEBUG);
    usart_baudrate_set(TREA_UART_DEBUG, 115200U);
    usart_word_length_set(TREA_UART_DEBUG, USART_WL_8BIT);
    usart_stop_bit_set(TREA_UART_DEBUG, USART_STB_1BIT);
    usart_parity_config(TREA_UART_DEBUG, USART_PM_NONE);
    usart_receive_config(TREA_UART_DEBUG, USART_RECEIVE_ENABLE);
    usart_transmit_config(TREA_UART_DEBUG, USART_TRANSMIT_ENABLE);
    usart_enable(TREA_UART_DEBUG);
}


int serial_write(uint32_t uart, const uint8_t *data, uint16_t len)
{
    if(data == NULL || len == 0) return 0;
    for(uint16_t i = 0; i < len; i++) {
        trea_uart_send_byte(uart, data[i]);
    }
    return (int)len;
}

int lpuart_wait_for(const char *expect, uint32_t timeout_ms)
{
    if(expect == NULL || expect[0] == 0) return 0;
    uint32_t start = trea_millis();
    char rx[256];
    uint16_t n = 0;
    rx[0] = 0;

    while((trea_millis() - start) < timeout_ms) {
        uint8_t ch = 0;
        if(trea_uart_recv_byte_timeout(TREA_UART_CAT1, &ch, 30)) {
            if(n < (uint16_t)(sizeof(rx) - 1)) {
                if(ch == '\r' || ch == '\n' || (ch >= 0x20U && ch <= 0x7EU)) {
                    rx[n++] = (char)ch;
                } else {
                    rx[n++] = '.';
                }
                rx[n] = 0;
            }
            if(strstr(rx, expect) != NULL) return 1;
        }
    }
    return 0;
}

int printf_debug(const char* fmt, ...)
{
    static char buf[256];
    va_list args;
    va_start(args, fmt);
    int n = vsnprintf(buf, sizeof(buf), fmt, args);
    va_end(args);
    if(n < 0) return n;
    if(n > (int)sizeof(buf)) n = sizeof(buf);
    serial_write(TREA_UART_DEBUG, (const uint8_t*)buf, (uint16_t)n);
    return n;
}

int printf_cat1(const char* fmt, ...)
{
    static char buf[256];
    va_list args;
    va_start(args, fmt);
    int n = vsnprintf(buf, sizeof(buf), fmt, args);
    va_end(args);
    if(n < 0) return n;
    if(n > (int)sizeof(buf)) n = sizeof(buf);
    serial_write(TREA_UART_CAT1, (const uint8_t*)buf, (uint16_t)n);
	memset(buf,0,sizeof(buf));
    return n;
}


// ===================== 【封装1】LPUART唤醒初始化 =====================
void lpuart_wakeup_init(void)
{
    // LPUART时钟 = 内部IRC16M
    rcu_lpuart_clock_config(RCU_LPUARTSRC_IRC16MDIV);

    // 唤醒中断 + EXTI配置
    nvic_irq_enable(LPUART_WKUP_IRQn, 0);
    exti_init(EXTI_28, EXTI_INTERRUPT, EXTI_TRIG_RISING);

    // 起始位唤醒
    lpuart_wakeup_mode_config(LPUART0, LPUART_WUM_STARTB);
    lpuart_enable(LPUART0);

    while(RESET == lpuart_flag_get(LPUART0, LPUART_FLAG_REA));
    while(SET == lpuart_flag_get(LPUART0, LPUART_FLAG_BSY));

    lpuart_wakeup_enable(LPUART0);
    lpuart_interrupt_enable(LPUART0, LPUART_INT_WU);
}

// ===================== 【封装2】进入深休眠 =====================
// 支持两种唤醒源: LPUART (counter0) 或 RTC闹钟 (rtc_alarm_flag)
void enter_deepsleep_mode(void)
{
    extern volatile uint8_t rtc_alarm_flag;

    counter0 = 0x00;
    rtc_alarm_flag = 0;

    rcu_periph_clock_enable(RCU_PMU);
    pmu_to_deepsleepmode(PMU_LDNPDSP_LOWDRIVE, WFI_CMD, PMU_DEEPSLEEP);

    // 等待任意唤醒源
    while((0x00 == counter0) && (0 == rtc_alarm_flag));
}

// ===================== 【封装3】唤醒后系统重新初始化 =====================
void system_wakeup_reinit(void)
{
    // 恢复时钟 + 滴答定时器（必须最先执行）
    system_clock_reconfig();
    systick_config();
    my_systick_config();

    // 无论哪种唤醒源，都必须关闭LPUART唤醒模式和中断
    // 否则LPUART唤醒中断持续触发，无法再次进入深休眠
    lpuart_wakeup_disable(LPUART0);
    lpuart_interrupt_disable(LPUART0, LPUART_INT_WU);
    exti_flag_clear(EXTI_28);

    // LPUART唤醒时：消费触发唤醒的字节
    if(counter0 != 0x00)
    {
        while(RESET == lpuart_flag_get(LPUART0, LPUART_FLAG_RBNE));
        lpuart_data_receive(LPUART0);
        lpuart_receive_config(LPUART0, LPUART_RECEIVE_ENABLE);
        while(RESET == lpuart_flag_get(LPUART0, LPUART_FLAG_TC));
        lpuart_disable(LPUART0);
    }
}

// ===================== LPUART初始化 =====================
void com_lpuart_init(void)
{
    rcu_periph_clock_enable(RCU_GPIOA);
    rcu_periph_clock_enable(RCU_LPUART);

    gpio_af_set(GPIOA, GPIO_AF_8, GPIO_PIN_2);
    gpio_af_set(GPIOA, GPIO_AF_8, GPIO_PIN_3);

    gpio_mode_set(GPIOA, GPIO_MODE_AF, GPIO_PUPD_PULLUP, GPIO_PIN_2);
    gpio_output_options_set(GPIOA, GPIO_OTYPE_PP, GPIO_OSPEED_10MHZ, GPIO_PIN_2);
    gpio_mode_set(GPIOA, GPIO_MODE_AF, GPIO_PUPD_PULLUP, GPIO_PIN_3);
    gpio_output_options_set(GPIOA, GPIO_OTYPE_PP, GPIO_OSPEED_10MHZ, GPIO_PIN_3);

    lpuart_deinit(LPUART0);
    lpuart_word_length_set(LPUART0, LPUART_WL_8BIT);
    lpuart_stop_bit_set(LPUART0, LPUART_STB_1BIT);
    lpuart_parity_config(LPUART0, LPUART_PM_NONE);
    lpuart_baudrate_set(LPUART0, 115200U);
    lpuart_receive_config(LPUART0, LPUART_RECEIVE_ENABLE);
    lpuart_transmit_config(LPUART0, LPUART_TRANSMIT_ENABLE);
    lpuart_enable(LPUART0);
}

// ===================== 时钟配置 =====================
static void system_clock_reconfig(void)
{
    RCU_CTL |= RCU_CTL_IRC16MEN;
    while(rcu_osci_stab_wait(RCU_IRC16M) != SUCCESS);

    rcu_ahb_clock_config(RCU_AHB_CKSYS_DIV1);
    rcu_apb1_clock_config(RCU_APB1_CKAHB_DIV1);
    rcu_apb2_clock_config(RCU_APB2_CKAHB_DIV1);

    RCU_CTL &= ~RCU_CTL_PLLEN;
    RCU_CFG0 &= ~RCU_CFG0_SCS;
    RCU_CFG0 |= RCU_CKSYSSRC_IRC16M;
}
