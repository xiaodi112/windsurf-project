#include "gd32l23x.h"
#include <stdio.h>
#include "myusart.h"



#define USART0_RDATA_ADDRESS      (&USART_RDATA(USART0))
#define USART0_TDATA_ADDRESS      (&USART_TDATA(USART0))

UCB_CB U0CB;
uint8_t U0_RxBuff[U0_RX_SIZE];
uint8_t U0_TxBuff[U0_TX_SIZE];





void Usart0_Init(uint32_t bandrate)
{
	/* enable USART clock */
    rcu_periph_clock_enable(RCU_USART0);

    /* enable COM GPIO clock */
    rcu_periph_clock_enable(RCU_GPIOC);

    /* connect port to USART TX */
    gpio_af_set(GPIOC, GPIO_AF_7, GPIO_PIN_4);

    /* connect port to USART RX */
    gpio_af_set(GPIOC, GPIO_AF_7, GPIO_PIN_5);

    /* configure USART TX as alternate function push-pull */
    gpio_mode_set(GPIOC, GPIO_MODE_AF, GPIO_PUPD_PULLUP, GPIO_PIN_4);
    gpio_output_options_set(GPIOC, GPIO_OTYPE_PP, GPIO_OSPEED_10MHZ, GPIO_PIN_4);

    /* configure USART RX as alternate function push-pull */
    gpio_mode_set(GPIOC, GPIO_MODE_AF, GPIO_PUPD_PULLUP, GPIO_PIN_5);
    gpio_output_options_set(GPIOC, GPIO_OTYPE_PP, GPIO_OSPEED_10MHZ, GPIO_PIN_5);

    /* USART configure */
    usart_deinit(USART0);
    usart_baudrate_set(USART0, 115200U);
    usart_receive_config(USART0, USART_RECEIVE_ENABLE);
    usart_transmit_config(USART0, USART_TRANSMIT_ENABLE);
	
	nvic_irq_enable(USART0_IRQn,0);
	usart_interrupt_enable(USART0,USART_INT_IDLE);


	U0Rx_PrtInit();
	
    usart_enable(USART0);


}

void DMA_Init(void)
{
	
	dma_parameter_struct dma_init_struct;
    /* enable DMA clock */
    rcu_periph_clock_enable(RCU_DMA);
    /* initialize the com */
    Usart0_Init(115200);
	/* initialize DMA channel 1 */
    dma_deinit(DMA_CH0);
    dma_struct_para_init(&dma_init_struct);
    dma_init_struct.request      = DMA_REQUEST_USART0_RX;
    dma_init_struct.direction    = DMA_PERIPHERAL_TO_MEMORY;
    dma_init_struct.memory_addr  = (uint32_t)U0_RxBuff;
    dma_init_struct.memory_inc   = DMA_MEMORY_INCREASE_ENABLE;
    dma_init_struct.memory_width = DMA_MEMORY_WIDTH_8BIT;
    dma_init_struct.number       = U0_RX_MAX + 1;
    dma_init_struct.periph_addr  = (uint32_t)USART0_RDATA_ADDRESS;
    dma_init_struct.periph_inc   = DMA_PERIPH_INCREASE_DISABLE;
    dma_init_struct.periph_width = DMA_PERIPHERAL_WIDTH_8BIT;
    dma_init_struct.priority     = DMA_PRIORITY_ULTRA_HIGH;
    dma_init(DMA_CH0, &dma_init_struct);

    /* configure DMA mode */
    dma_circulation_disable(DMA_CH0);

    usart_dma_receive_config(USART0, USART_RECEIVE_DMA_ENABLE);

    dma_channel_enable(DMA_CH0);
}



void U0Rx_PrtInit(void)
{
	U0CB.URxDataIN = &U0CB.URxDataPrt[0];
	U0CB.URxDataOUT = &U0CB.URxDataPrt[0];
	U0CB.URxDataEND = &U0CB.URxDataPrt[9];
	U0CB.URxDataIN->start = U0_RxBuff;
	U0CB.URxcounter = 0;
}



void u0_printf(char *format,...)
{
	uint16_t i;
	va_list listdata;
	va_start(listdata,format);
	vsprintf((char *)U0_TxBuff,format,listdata);
	va_end(listdata);
	
	for(i = 0; i<strlen((const char*)U0_TxBuff); i++)
	{
		while(usart_flag_get(USART0,USART_FLAG_TBE) != 1);
		usart_data_transmit(USART0,U0_TxBuff[i]);
	}
	while(usart_flag_get(USART0,USART_FLAG_TC) != 1);
}












