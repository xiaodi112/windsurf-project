./objects/sensor_buffer.o: my_Library\sensor_buffer.c \
  my_Library\sensor_buffer.h
